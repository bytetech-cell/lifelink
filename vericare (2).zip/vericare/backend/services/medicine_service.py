"""Medicine search, composition matching, unit prices and price freshness.

Core rule: two products are only treated as the same medicine when the active
ingredient(s), strength and dosage form all match. Similar names never count.
If any of those three facts is missing, the match is flagged as uncertain.
"""
from __future__ import annotations

import math
import re
from datetime import datetime, timedelta

from sqlalchemy import or_, select
from sqlalchemy.orm import Session, joinedload

from config import get_settings
from database import iso, utcnow
from models import Medicine, PharmacyListing
from services import verification_service

# ---------------------------------------------------------------- normalising

_FORM_ALIASES = {
    "tab": "tablet", "tabs": "tablet", "tablet": "tablet", "tablets": "tablet",
    "film coated tablet": "tablet", "film-coated tablet": "tablet",
    "cap": "capsule", "caps": "capsule", "capsule": "capsule", "capsules": "capsule",
    "syp": "syrup", "syrup": "syrup", "suspension": "suspension", "oral suspension": "suspension",
    "drops": "drops", "drop": "drops", "injection": "injection", "inj": "injection",
    "cream": "cream", "ointment": "ointment", "gel": "gel", "inhaler": "inhaler",
}

_UNIT_TO_MG = {"mg": 1.0, "g": 1000.0, "mcg": 0.001, "µg": 0.001, "ug": 0.001}


def normalize_ingredient(value: str | None) -> tuple[str, ...] | None:
    """'Amoxicillin + Clavulanic Acid' -> ('amoxicillin', 'clavulanic acid'). Order-independent."""
    if not value or not value.strip():
        return None
    parts = re.split(r"\s*(?:\+|,|/|&|\band\b)\s*", value.lower())
    cleaned = sorted({re.sub(r"\s+", " ", p).strip() for p in parts if p.strip()})
    return tuple(cleaned) or None


def normalize_strength(value: str | None) -> tuple[tuple[float, str], ...] | None:
    """'500 mg' -> ((500.0, 'mg'),); '0.5 g' -> ((500.0, 'mg'),); '250mg/5ml' keeps the per-volume part."""
    if not value or not value.strip():
        return None
    text = value.lower().replace(" ", "")
    found = re.findall(r"(\d+(?:\.\d+)?)(mg|g|mcg|µg|ug|ml|iu|%)", text)
    if not found:
        return None
    out = []
    for number, unit in found:
        n = float(number)
        if unit in _UNIT_TO_MG:
            out.append((round(n * _UNIT_TO_MG[unit], 4), "mg"))
        else:
            out.append((n, unit))
    return tuple(out)


def normalize_form(value: str | None) -> str | None:
    if not value or not value.strip():
        return None
    key = value.strip().lower()
    return _FORM_ALIASES.get(key, key)


def compare_composition(a: dict, b: dict) -> dict:
    """Compare two products' composition.

    Returns {"match": "same" | "uncertain" | "different", "reasons": [...]}.
    a / b are dicts with keys active_ingredient, strength, dosage_form.
    """
    reasons: list[str] = []
    checks = [
        ("active ingredient", normalize_ingredient(a.get("active_ingredient")), normalize_ingredient(b.get("active_ingredient"))),
        ("strength", normalize_strength(a.get("strength")), normalize_strength(b.get("strength"))),
        ("dosage form", normalize_form(a.get("dosage_form")), normalize_form(b.get("dosage_form"))),
    ]
    missing = False
    for label, x, y in checks:
        if x is None or y is None:
            missing = True
            reasons.append(f"{label} not known for both products")
        elif x != y:
            reasons.append(f"{label} differs")
            return {"match": "different", "reasons": reasons}
    if missing:
        return {"match": "uncertain", "reasons": reasons}
    return {"match": "same", "reasons": ["active ingredient, strength and dosage form all match"]}


# ---------------------------------------------------------------- prices

def unit_price(price: float | None, pack_size: int | float | None) -> float | None:
    """Price per unit, or None when either number is missing or invalid."""
    if price is None or pack_size is None:
        return None
    try:
        price_f, pack_f = float(price), float(pack_size)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(price_f) or not math.isfinite(pack_f) or price_f < 0 or pack_f <= 0:
        return None
    return round(price_f / pack_f, 2)


def price_freshness(observed_at: datetime | None, now: datetime | None = None, days: int | None = None) -> str:
    """'fresh', 'possibly_outdated', or 'unknown' (no observation time)."""
    if observed_at is None:
        return "unknown"
    now = now or utcnow()
    days = get_settings().price_freshness_days if days is None else days
    return "possibly_outdated" if now - observed_at > timedelta(days=days) else "fresh"


# ---------------------------------------------------------------- serialising

def medicine_dict(m: Medicine) -> dict:
    return {
        "id": m.id,
        "name": m.name,
        "active_ingredient": m.active_ingredient,
        "strength": m.strength,
        "dosage_form": m.dosage_form,
        "is_demo": m.is_demo,
    }


def haversine_km(lat1, lon1, lat2, lon2) -> float | None:
    if None in (lat1, lon1, lat2, lon2):
        return None
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return round(2 * r * math.asin(math.sqrt(a)), 2)


def listing_dict(listing: PharmacyListing, lat: float | None = None, lng: float | None = None, now=None) -> dict:
    now = now or utcnow()
    ph = listing.pharmacy
    stock = verification_service.current_stock_status(listing.confirmations, now=now)
    return {
        "id": listing.id,
        "product_name": listing.product_name,
        "medicine": medicine_dict(listing.medicine),
        "pharmacy": {
            "id": ph.id,
            "name": ph.name,
            "address": ph.address,
            "phone": ph.phone,
            "latitude": ph.latitude,
            "longitude": ph.longitude,
            "is_demo": ph.is_demo,
        },
        "distance_km": haversine_km(lat, lng, ph.latitude, ph.longitude),
        "pack_size": listing.pack_size,
        "pack_unit": listing.pack_unit,
        "price": listing.price,
        "currency": listing.currency,
        "unit_price": unit_price(listing.price, listing.pack_size),
        "price_note": "Listed price. Final checkout price may differ.",
        "price_observed_at": iso(listing.price_observed_at),
        "price_freshness": price_freshness(listing.price_observed_at, now=now),
        "product_url": listing.product_url,
        "source": {
            "kind": listing.source.kind if listing.source else None,
            "name": listing.source.name if listing.source else None,
            "url": listing.source.url if listing.source else None,
        },
        "stock": stock,
        "is_demo": listing.is_demo,
    }


# ---------------------------------------------------------------- queries

def _listing_query():
    return select(PharmacyListing).options(
        joinedload(PharmacyListing.pharmacy),
        joinedload(PharmacyListing.medicine),
        joinedload(PharmacyListing.source),
        joinedload(PharmacyListing.confirmations),
    )


def search_listings(db: Session, q: str, lat=None, lng=None, urgent: bool = False) -> dict:
    """Search the local database by medicine name, ingredient or product name."""
    term = f"%{q.strip()}%"
    stmt = _listing_query().join(PharmacyListing.medicine).where(
        or_(
            Medicine.name.ilike(term),
            Medicine.active_ingredient.ilike(term),
            PharmacyListing.product_name.ilike(term),
        )
    )
    listings = db.execute(stmt).unique().scalars().all()
    now = utcnow()
    items = [listing_dict(li, lat, lng, now=now) for li in listings]

    medicines = {}
    for it in items:
        medicines[it["medicine"]["id"]] = it["medicine"]

    if urgent:
        ranked = verification_service.rank_urgent(items)
        return {"mode": "urgent", "medicines": list(medicines.values()), **ranked}

    # Normal mode: group by exact composition so only compatible products are price-compared.
    groups: dict[tuple, list[dict]] = {}
    for it in items:
        m = it["medicine"]
        key = (
            normalize_ingredient(m["active_ingredient"]),
            normalize_strength(m["strength"]),
            normalize_form(m["dosage_form"]),
        )
        groups.setdefault(key, []).append(it)
    out_groups = []
    for key, group in groups.items():
        complete = all(part is not None for part in key)
        group.sort(key=lambda x: (x["unit_price"] is None, x["unit_price"] or 0))
        first = group[0]["medicine"]
        out_groups.append({
            "composition": {
                "active_ingredient": first["active_ingredient"],
                "strength": first["strength"],
                "dosage_form": first["dosage_form"],
            },
            "comparable": complete,
            "review_note": None if complete else "Composition incomplete — check with a pharmacist before comparing.",
            "listings": group,
        })
    return {"mode": "compare", "medicines": list(medicines.values()), "groups": out_groups}


def alternatives(db: Session, medicine_id: int) -> dict | None:
    base = db.get(Medicine, medicine_id)
    if base is None:
        return None
    base_d = medicine_dict(base)
    others = db.execute(select(Medicine).where(Medicine.id != medicine_id)).scalars().all()
    same, uncertain = [], []
    for m in others:
        result = compare_composition(base_d, medicine_dict(m))
        entry = {**medicine_dict(m), "match": result["match"], "reasons": result["reasons"]}
        if result["match"] == "same":
            same.append(entry)
        elif result["match"] == "uncertain" and _shares_ingredient(base_d, entry):
            uncertain.append(entry)
    return {
        "medicine": base_d,
        "same_composition": same,
        "needs_review": uncertain,
        "note": "Same composition does not mean you should switch. Ask your doctor or pharmacist before changing medicine.",
    }


def _shares_ingredient(a: dict, b: dict) -> bool:
    ia, ib = normalize_ingredient(a.get("active_ingredient")), normalize_ingredient(b.get("active_ingredient"))
    if ia is None or ib is None:
        # Only flag unknown-ingredient products when their names look related.
        return a["name"].split()[0].lower() in (b["name"] or "").lower()
    return bool(set(ia) & set(ib))

import { useEffect, useRef, useState } from 'react';
import { AlertTriangle, Globe, Info, PhoneCall, Search, ShieldCheck, Zap } from 'lucide-react';
import { api } from '../services/api.js';
import { useLocation } from '../services/location.jsx';
import { hostOf } from '../services/format.js';
import LocationInput from '../components/LocationInput.jsx';
import { ListingCard, LiveProductCard } from '../components/ListingCard.jsx';
import { AlternativesDialog, VerifyStockDialog } from '../components/Dialogs.jsx';
import { Empty, ErrorState, Loading, Notice } from '../components/Status.jsx';

export default function MedicineFinder() {
  const { location } = useLocation();
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [urgent, setUrgent] = useState(false);
  const [demo, setDemo] = useState({ loading: false, error: null, data: null });
  const [live, setLive] = useState({ loading: false, error: null, data: null, demoFallback: false });
  const [config, setConfig] = useState(null);
  const [site, setSite] = useState('');
  const [verifyItem, setVerifyItem] = useState(null);
  const [altMedicine, setAltMedicine] = useState(null);
  const abortRef = useRef(null);

  useEffect(() => {
    api
      .config()
      .then((r) => {
        setConfig(r.data);
        setSite(r.data.permitted_pharmacy_sites[0] || '');
      })
      .catch(() => setConfig({ tinyfish_configured: false, permitted_pharmacy_sites: [] }));
  }, []);

  // Re-run demo search when urgent mode or location changes.
  useEffect(() => {
    if (submitted) runDemo(submitted);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urgent, location?.latitude, location?.longitude]);

  async function runDemo(q) {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setDemo((s) => ({ ...s, loading: true, error: null }));
    try {
      const r = await api.searchMedicines(
        { q, lat: location?.latitude, lng: location?.longitude, urgent },
        ctrl.signal,
      );
      setDemo({ loading: false, error: null, data: r.data });
    } catch (e) {
      if (e.name === 'AbortError') return;
      setDemo({ loading: false, error: e.message, data: null });
    }
  }

  async function runLive() {
    const q = query.trim();
    if (q.length < 2) return;
    setLive({ loading: true, error: null, data: null, demoFallback: false });
    try {
      const r = await api.liveSearch({ medicine_name: q, site_url: site });
      setLive({ loading: false, error: null, data: r.data, demoFallback: false });
    } catch (e) {
      setLive({ loading: false, error: e.message, data: null, demoFallback: e.demoFallback });
    }
  }

  const onSubmit = (e) => {
    e.preventDefault();
    const q = query.trim();
    if (q.length < 2) return;
    setSubmitted(q);
    runDemo(q);
  };

  const count = demo.data
    ? demo.data.mode === 'urgent'
      ? demo.data.verified.length + demo.data.unconfirmed.length
      : demo.data.groups.reduce((n, g) => n + g.listings.length, 0)
    : 0;

  return (
    <div className="container page">
      <header className="page-head">
        <h1>Find Medicine</h1>
        <p className="lead">Search by brand or ingredient. Prices are compared per unit, only between identical compositions.</p>
      </header>

      <div className="card search-panel">
        <form className="search-row" onSubmit={onSubmit} role="search">
          <label htmlFor="med-q" className="sr-only">
            Medicine name
          </label>
          <div className="input-icon grow">
            <Search size={18} aria-hidden="true" />
            <input
              id="med-q"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. Paracetamol, Amoxicillin, Cetirizine"
              maxLength={80}
              autoComplete="off"
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={query.trim().length < 2 || demo.loading}>
            Search demo database
          </button>
        </form>

        <div className="search-options">
          <label className={`switch ${urgent ? 'switch-on' : ''}`}>
            <input type="checkbox" role="switch" checked={urgent} onChange={(e) => setUrgent(e.target.checked)} aria-describedby="urgent-help" />
            <span className="switch-track" aria-hidden="true">
              <span className="switch-thumb" />
            </span>
            <span className="switch-label">
              <Zap size={15} aria-hidden="true" /> Urgent Mode
            </span>
          </label>
          <span id="urgent-help" className="muted small">
            {urgent ? 'Confirmed stock first, nearest first. Price is ignored.' : 'Compare compatible products by unit price.'}
          </span>
        </div>

        <LocationInput compact />

        <div className="live-panel">
          <div className="live-head">
            <Globe size={18} aria-hidden="true" />
            <div>
              <strong>Live lookup with TinyFish</strong>
              <p className="muted small">
                An AI browser agent visits a permitted pharmacy website and reads what is visibly listed. Takes 30–120
                seconds.
              </p>
            </div>
          </div>
          {config && !config.tinyfish_configured ? (
            <p className="muted small">
              <Info size={14} aria-hidden="true" /> Live lookup is not configured on this server. Add{' '}
              <code>TINYFISH_API_KEY</code> and <code>PHARMACY_SITE_URL</code> to <code>backend/.env</code>.
            </p>
          ) : (
            <div className="live-row">
              <label htmlFor="site" className="sr-only">
                Pharmacy website
              </label>
              <select id="site" value={site} onChange={(e) => setSite(e.target.value)} disabled={!config}>
                {(config?.permitted_pharmacy_sites || []).map((s) => (
                  <option key={s} value={s}>
                    {hostOf(s)}
                  </option>
                ))}
              </select>
              <button className="btn btn-secondary" onClick={runLive} disabled={!config || live.loading || query.trim().length < 2}>
                {live.loading ? 'Searching live…' : 'Run live lookup'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ---------- live results ---------- */}
      {(live.loading || live.error || live.data) && (
        <section className="results" aria-labelledby="live-h">
          <h2 id="live-h" className="results-title">
            Live results {live.data && <span className="muted">from {hostOf(live.data.source_website)}</span>}
          </h2>
          {live.loading && <Loading label="TinyFish is browsing the pharmacy website… this can take a minute or two." />}
          {live.error && (
            <ErrorState
              title="Live lookup failed"
              message={live.error}
              action={
                live.demoFallback && query.trim().length >= 2 ? (
                  <button className="btn btn-ghost" onClick={() => { setSubmitted(query.trim()); runDemo(query.trim()); }}>
                    Show demo data instead (clearly labelled)
                  </button>
                ) : null
              }
            />
          )}
          {live.data && (
            <>
              <Notice tone="info" icon={Info}>
                {live.data.notice}
                {live.data.rejected_count > 0 && <> {live.data.rejected_count} result(s) failed validation and were hidden.</>}
                {live.data.page_note && <> Agent note: “{live.data.page_note}”</>}
              </Notice>
              {live.data.products.length === 0 ? (
                <Empty title="No products found on the website">Try a different spelling or the generic name.</Empty>
              ) : (
                <div className="listing-stack">
                  {live.data.products.map((p, i) => (
                    <LiveProductCard key={`${p.product_name}-${i}`} p={p} />
                  ))}
                </div>
              )}
            </>
          )}
        </section>
      )}

      {/* ---------- demo database results ---------- */}
      {submitted && (
        <section className="results" aria-labelledby="demo-h">
          <h2 id="demo-h" className="results-title">
            Demo database results <span className="tag tag-demo">Fictional records</span>
          </h2>
          {demo.loading && <Loading label="Searching…" />}
          {demo.error && <ErrorState title="Search failed" message={demo.error} action={<button className="btn btn-ghost" onClick={() => runDemo(submitted)}>Try again</button>} />}
          {!demo.loading && !demo.error && demo.data && count === 0 && (
            <Empty title={`No matches for “${submitted}”`}>Try the ingredient name, e.g. “paracetamol”.</Empty>
          )}

          {!demo.loading && demo.data?.mode === 'urgent' && count > 0 && (
            <>
              <Notice tone="warn" icon={PhoneCall}>
                <strong>{demo.data.notice}</strong> Even confirmed stock can sell out.
              </Notice>
              {!location && <p className="muted small">Set your location to sort by distance.</p>}
              <h3 className="sub-title">
                <ShieldCheck size={18} aria-hidden="true" /> Recently confirmed ({demo.data.verified.length})
              </h3>
              {demo.data.verified.length === 0 ? (
                <Empty title="No pharmacy has a valid confirmation right now">Call the pharmacies below to check.</Empty>
              ) : (
                <div className="listing-stack">
                  {demo.data.verified.map((it, i) => (
                    <ListingCard key={it.id} item={it} highlight={i === 0} onVerify={setVerifyItem} />
                  ))}
                </div>
              )}
              <h3 className="sub-title muted-title">
                <AlertTriangle size={18} aria-hidden="true" /> Not confirmed — call first ({demo.data.unconfirmed.length})
              </h3>
              <div className="listing-stack dim">
                {demo.data.unconfirmed.map((it) => (
                  <ListingCard key={it.id} item={it} onVerify={setVerifyItem} />
                ))}
              </div>
            </>
          )}

          {!demo.loading && demo.data?.mode === 'compare' &&
            demo.data.groups.map((g, gi) => (
              <div className="group" key={gi}>
                <div className="group-head">
                  <h3>
                    {g.composition.active_ingredient || 'Unknown ingredient'} · {g.composition.strength || 'strength unknown'} ·{' '}
                    {g.composition.dosage_form || 'form unknown'}
                  </h3>
                  {g.comparable ? (
                    <span className="tag tag-ok">Same composition — sorted by unit price</span>
                  ) : (
                    <span className="tag tag-warn">{g.review_note}</span>
                  )}
                </div>
                <div className="listing-stack">
                  {g.listings.map((it) => (
                    <ListingCard key={it.id} item={it} onVerify={setVerifyItem} onAlternatives={setAltMedicine} />
                  ))}
                </div>
              </div>
            ))}
          {demo.data && count > 0 && (
            <p className="muted small disclaimer">
              VeriCare does not give dosage advice. Do not change prescribed medicine without asking your doctor or
              pharmacist.
            </p>
          )}
        </section>
      )}

      {!submitted && !live.data && !live.loading && !live.error && (
        <Empty title="Search for a medicine to begin">Try “paracetamol” to see confirmed, expired and unconfirmed examples.</Empty>
      )}

      {verifyItem && <VerifyStockDialog item={verifyItem} onClose={() => setVerifyItem(null)} />}
      {altMedicine && <AlternativesDialog medicine={altMedicine} onClose={() => setAltMedicine(null)} />}
    </div>
  );
}

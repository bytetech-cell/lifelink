"""VeriCare API — FastAPI application.

Every success response:  {"ok": true,  "data": ..., "meta": {...}}
Every error response:    {"ok": false, "error": {"code": "...", "message": "..."}}
"""
from __future__ import annotations

import asyncio
import hmac
import logging
from contextlib import asynccontextmanager
from datetime import timedelta, timezone

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from config import get_settings
from database import SessionLocal, get_db, init_db, iso, utcnow
from models import LookupLog, Pharmacy, PharmacyListing, StockConfirmation
from schemas import ConfirmationCreate, TinyFishSearchRequest
from services import emergency_service, medicine_service, tinyfish_service, verification_service

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("vericare")

# TinyFish allows a small number of concurrent runs; queue the rest politely.
_tinyfish_slots = asyncio.Semaphore(2)


class ApiError(HTTPException):
    def __init__(self, status: int, code: str, message: str, extra: dict | None = None):
        super().__init__(status_code=status, detail=message)
        self.code = code
        self.extra = extra or {}


def ok(data, **meta):
    return {"ok": True, "data": data, "meta": {"generated_at": iso(utcnow()), **meta}}


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    from seed import seed_demo

    with SessionLocal() as db:
        seed_demo(db)  # fresh, clearly-labelled demo data on each start
    s = get_settings()
    log.info(
        "VeriCare started. TinyFish key configured: %s. Permitted pharmacy sites: %d. Live OSM: %s",
        "yes" if s.tinyfish_api_key else "no", len(s.pharmacy_site_urls), s.enable_osm_live,
    )
    yield


app = FastAPI(title="VeriCare API", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in get_settings().frontend_origins.split(",") if o.strip()],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-Confirmer-Token"],
)


@app.exception_handler(ApiError)
async def _api_error(_: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status_code, content={"ok": False, "error": {"code": exc.code, "message": exc.detail, **exc.extra}})


@app.exception_handler(HTTPException)
async def _http_error(_: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"ok": False, "error": {"code": "http_error", "message": str(exc.detail)}})


@app.exception_handler(RequestValidationError)
async def _validation_error(_: Request, exc: RequestValidationError):
    first = exc.errors()[0] if exc.errors() else {}
    field = ".".join(str(p) for p in first.get("loc", []) if p not in ("body", "query"))
    msg = str(first.get("msg", "Invalid input")).removeprefix("Value error, ")
    return JSONResponse(
        status_code=422,
        content={"ok": False, "error": {"code": "invalid_input", "message": f"{field}: {msg}" if field else msg}},
    )


def _log_lookup(db: Session, **fields) -> None:
    try:
        db.add(LookupLog(**fields))
        db.commit()
    except Exception:  # logging must never break a request
        db.rollback()


# ------------------------------------------------------------------ meta

@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    s = get_settings()
    return ok({
        "status": "ok",
        "database": "ok",
        "tinyfish": "configured" if s.tinyfish_configured else "not_configured",
        "osm_live": s.enable_osm_live,
    })


@app.get("/api/config")
def public_config():
    """Non-secret settings the frontend needs. Never includes the API key."""
    s = get_settings()
    return ok({
        "price_freshness_days": s.price_freshness_days,
        "confirmation_expiry_minutes": s.confirmation_expiry_minutes,
        "tinyfish_configured": s.tinyfish_configured,
        "permitted_pharmacy_sites": s.pharmacy_site_urls,
        "osm_live": s.enable_osm_live,
        "demo_areas": [v[0] for v in emergency_service.DEMO_AREAS.values()],
        "emergency_number": emergency_service.emergency_number("IN"),
    })


@app.get("/api/geocode")
async def geocode(q: str = Query(min_length=2, max_length=120)):
    result = await emergency_service.geocode(q)
    if result is None:
        raise ApiError(404, "location_not_found", "Could not find that area. Try a nearby landmark or use your current location.")
    return ok(result)


# ------------------------------------------------------------------ medicines

@app.get("/api/medicines/search")
def medicine_search(
    q: str = Query(min_length=2, max_length=80),
    lat: float | None = Query(default=None, ge=-90, le=90),
    lng: float | None = Query(default=None, ge=-180, le=180),
    urgent: bool = False,
    db: Session = Depends(get_db),
):
    started = utcnow()
    data = medicine_service.search_listings(db, q, lat=lat, lng=lng, urgent=urgent)
    count = len(data.get("verified", [])) + len(data.get("unconfirmed", [])) if urgent else sum(len(g["listings"]) for g in data["groups"])
    _log_lookup(db, lookup_type="medicine_demo", query=q, outcome="ok" if count else "empty", result_count=count, started_at=started, finished_at=utcnow())
    return ok(data, count=count, data_source="local_database", contains_demo=True)


@app.get("/api/medicines/{medicine_id}/alternatives")
def medicine_alternatives(medicine_id: int, db: Session = Depends(get_db)):
    data = medicine_service.alternatives(db, medicine_id)
    if data is None:
        raise ApiError(404, "not_found", "Medicine not found.")
    return ok(data)


@app.post("/api/tinyfish/medicine-search")
async def tinyfish_medicine_search(req: TinyFishSearchRequest, db: Session = Depends(get_db)):
    started = utcnow()
    target = req.site_url or (get_settings().pharmacy_site_urls[:1] or [None])[0]
    try:
        async with _tinyfish_slots:
            data = await tinyfish_service.search_medicine(req.medicine_name, req.site_url)
    except tinyfish_service.TinyFishError as exc:
        outcome = "timeout" if isinstance(exc, tinyfish_service.TinyFishTimeout) else (
            "unavailable" if isinstance(exc, tinyfish_service.TinyFishNotConfigured) else "error")
        _log_lookup(db, lookup_type="tinyfish", query=req.medicine_name, target=target, outcome=outcome, started_at=started, finished_at=utcnow())
        raise ApiError(exc.http_status, exc.code, exc.message, {"demo_fallback_available": True})
    _log_lookup(
        db, lookup_type="tinyfish", query=req.medicine_name, target=data["source_website"],
        outcome="ok" if data["products"] else "empty", result_count=len(data["products"]),
        external_run_id=data["run_id"], started_at=started, finished_at=utcnow(),
    )
    return ok(data, data_source="tinyfish_live", contains_demo=False)


# ------------------------------------------------------------------ pharmacies

@app.get("/api/pharmacies/nearby")
def pharmacies_nearby(
    lat: float = Query(ge=-90, le=90),
    lng: float = Query(ge=-180, le=180),
    radius_km: float = Query(default=15, gt=0, le=100),
    db: Session = Depends(get_db),
):
    rows = db.execute(select(Pharmacy)).scalars().all()
    items = []
    for p in rows:
        d = medicine_service.haversine_km(lat, lng, p.latitude, p.longitude)
        if d is not None and d <= radius_km:
            items.append({
                "id": p.id, "name": p.name, "address": p.address, "phone": p.phone,
                "latitude": p.latitude, "longitude": p.longitude, "distance_km": d,
                "directions_url": emergency_service.directions_url(p.latitude, p.longitude, lat, lng),
                "is_demo": p.is_demo,
            })
    items.sort(key=lambda i: i["distance_km"])
    return ok(items, count=len(items))


# ------------------------------------------------------------------ emergency

@app.get("/api/emergency/nearby")
async def emergency_nearby(
    lat: float | None = Query(default=None, ge=-90, le=90),
    lng: float | None = Query(default=None, ge=-180, le=180),
    area: str | None = Query(default=None, min_length=2, max_length=120),
    db: Session = Depends(get_db),
):
    location = None
    if lat is None or lng is None:
        if not area:
            raise ApiError(422, "invalid_input", "Give a location: an area name or your coordinates.")
        location = await emergency_service.geocode(area)
        if location is None:
            raise ApiError(404, "location_not_found", "Could not find that area. Try a nearby landmark or use your current location.")
        lat, lng = location["latitude"], location["longitude"]
    else:
        location = {"label": "Your location", "latitude": lat, "longitude": lng, "source": "device"}

    started = utcnow()
    mode, results = "demo", None
    if get_settings().enable_osm_live:
        results = await emergency_service.nearby_live_osm(lat, lng)
        if results is not None:
            mode = "live_osm"
    if results is None:
        results = emergency_service.nearby_from_db(db, lat, lng)
    _log_lookup(db, lookup_type="emergency", query=area or f"{lat:.3f},{lng:.3f}", target=mode,
                outcome="ok" if results else "empty", result_count=len(results), started_at=started, finished_at=utcnow())
    return ok(
        {
            "location": location,
            "emergency_number": emergency_service.emergency_number("IN"),
            "results": results,
            "notice": "VeriCare does not know whether beds, ambulances or specialists are available. In an emergency, call the emergency number first.",
        },
        source_mode=mode, count=len(results),
    )


# ------------------------------------------------------------------ confirmations

def _confirmation_dict(c: StockConfirmation) -> dict:
    return {
        "id": c.id,
        "pharmacy_id": c.pharmacy_id,
        "listing_id": c.listing_id,
        "reported_status": c.status,
        "confirmation_source": c.confirmation_source,
        "confirmed_by": c.confirmed_by,
        "confirmed_at": iso(c.confirmed_at),
        "expires_at": iso(c.expires_at),
        "note": c.note,
        "is_demo": c.is_demo,
        "evaluated_status": verification_service.evaluate_confirmation(c),
        "evaluated_label": verification_service.STATUS_LABELS[verification_service.evaluate_confirmation(c)],
    }


@app.get("/api/confirmations/{confirmation_id}")
def get_confirmation(confirmation_id: int, db: Session = Depends(get_db)):
    c = db.get(StockConfirmation, confirmation_id)
    if c is None:
        raise ApiError(404, "not_found", "Confirmation not found.")
    return ok(_confirmation_dict(c))


@app.post("/api/confirmations", status_code=201)
def create_confirmation(
    body: ConfirmationCreate,
    x_confirmer_token: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    """Record stock evidence from a trusted source. Requires the CONFIRMER_TOKEN shared secret."""
    expected = get_settings().confirmer_token
    if not expected:
        raise ApiError(403, "confirmations_disabled", "Stock confirmations are disabled until CONFIRMER_TOKEN is set on the server.")
    if not x_confirmer_token or not hmac.compare_digest(x_confirmer_token, expected):
        raise ApiError(401, "unauthorized", "A valid confirmer token is required to record stock confirmations.")

    listing = db.get(PharmacyListing, body.listing_id)
    if listing is None:
        raise ApiError(404, "not_found", "Listing not found.")

    now = utcnow()
    confirmed_at = now
    if body.confirmed_at is not None:
        ca = body.confirmed_at
        confirmed_at = ca.astimezone(timezone.utc).replace(tzinfo=None) if ca.tzinfo else ca
        if confirmed_at > now + timedelta(minutes=5):
            raise ApiError(422, "invalid_input", "confirmed_at cannot be in the future.")
        if now - confirmed_at > timedelta(minutes=get_settings().confirmation_expiry_minutes):
            raise ApiError(422, "invalid_input", "This confirmation is already older than the expiry window.")

    c = StockConfirmation(
        pharmacy_id=listing.pharmacy_id, listing_id=listing.id, status=body.status,
        confirmation_source=body.confirmation_source, confirmed_by=body.confirmed_by,
        confirmed_at=confirmed_at, expires_at=verification_service.expiry_for(confirmed_at),
        note=body.note, is_demo=False,
    )
    db.add(c)
    db.commit()
    db.refresh(c)
    log.info("Stock confirmation %s recorded for listing %s (%s)", c.id, listing.id, body.confirmation_source)
    return ok(_confirmation_dict(c))

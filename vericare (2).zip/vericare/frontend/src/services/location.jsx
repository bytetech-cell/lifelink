import { createContext, useCallback, useContext, useState } from 'react';
import { api } from './api.js';

const LocationCtx = createContext(null);
const KEY = 'vericare.location';

function load() {
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function save(loc) {
  try {
    if (loc) window.localStorage.setItem(KEY, JSON.stringify(loc));
    else window.localStorage.removeItem(KEY);
  } catch {
    /* storage may be blocked */
  }
}

export function LocationProvider({ children }) {
  const [location, setLocationState] = useState(load);
  const [status, setStatus] = useState({ loading: false, error: null });

  const setLocation = useCallback((loc) => {
    setLocationState(loc);
    save(loc);
  }, []);

  const lookupArea = useCallback(
    async (area) => {
      setStatus({ loading: true, error: null });
      try {
        const { data } = await api.geocode(area);
        setLocation(data);
        setStatus({ loading: false, error: null });
        return data;
      } catch (e) {
        setStatus({ loading: false, error: e.message });
        return null;
      }
    },
    [setLocation],
  );

  const useDevice = useCallback(() => {
    if (!navigator.geolocation) {
      setStatus({ loading: false, error: 'Your browser cannot share location. Type an area instead.' });
      return;
    }
    setStatus({ loading: true, error: null });
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({
          label: 'Your current location',
          latitude: Number(pos.coords.latitude.toFixed(5)),
          longitude: Number(pos.coords.longitude.toFixed(5)),
          source: 'device',
        });
        setStatus({ loading: false, error: null });
      },
      () => setStatus({ loading: false, error: 'Location permission was denied. Type an area instead.' }),
      { timeout: 10000 },
    );
  }, [setLocation]);

  return (
    <LocationCtx.Provider value={{ location, setLocation, lookupArea, useDevice, status }}>{children}</LocationCtx.Provider>
  );
}

export function useLocation() {
  return useContext(LocationCtx);
}

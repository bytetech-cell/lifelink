from services.emergency_service import parse_overpass


def test_emergency_by_area_returns_demo_unverified(client):
    r = client.get("/api/emergency/nearby", params={"area": "Connaught Place"})
    assert r.status_code == 200
    body = r.json()
    assert body["meta"]["source_mode"] == "demo"
    results = body["data"]["results"]
    assert results and all(x["is_demo"] and x["availability_verified"] is False for x in results)
    assert all(x["directions_url"].startswith("https://www.openstreetmap.org/") for x in results)
    dists = [x["distance_km"] for x in results]
    assert dists == sorted(dists)
    assert body["data"]["emergency_number"]["primary"] == "112"


def test_emergency_by_coordinates_and_errors(client):
    assert client.get("/api/emergency/nearby", params={"lat": 28.6, "lng": 77.2}).status_code == 200
    assert client.get("/api/emergency/nearby").status_code == 422
    assert client.get("/api/emergency/nearby", params={"area": "Atlantis Undersea"}).status_code == 404


def test_pharmacies_nearby(client):
    r = client.get("/api/pharmacies/nearby", params={"lat": 28.6315, "lng": 77.2167, "radius_km": 5})
    items = r.json()["data"]
    assert items and all(i["distance_km"] <= 5 for i in items)


def test_parse_overpass_is_always_unverified():
    data = {"elements": [
        {"type": "node", "id": 1, "lat": 28.63, "lon": 77.21, "tags": {"name": "Real Hospital", "amenity": "hospital", "emergency": "yes"}},
        {"type": "way", "id": 2, "center": {"lat": 28.64, "lon": 77.22}, "tags": {"amenity": "clinic"}},  # no name -> skipped
    ]}
    out = parse_overpass(data, 28.63, 77.21, "2026-10-18T00:00:00Z")
    assert len(out) == 1
    assert out[0]["availability_verified"] is False and out[0]["is_demo"] is False
    assert out[0]["has_emergency_department"] is True

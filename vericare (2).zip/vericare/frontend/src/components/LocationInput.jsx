import { useState } from 'react';
import { Crosshair, Loader2, MapPin } from 'lucide-react';
import { useLocation } from '../services/location.jsx';

export default function LocationInput({ compact = false }) {
  const { location, lookupArea, useDevice, status } = useLocation();
  const [area, setArea] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (area.trim().length >= 2) lookupArea(area.trim());
  };

  return (
    <div className={`location ${compact ? 'location-compact' : ''}`}>
      <form className="location-form" onSubmit={submit}>
        <label htmlFor="loc-input" className="sr-only">
          Your area
        </label>
        <div className="input-icon">
          <MapPin size={18} aria-hidden="true" />
          <input
            id="loc-input"
            value={area}
            onChange={(e) => setArea(e.target.value)}
            placeholder="Your area, e.g. Connaught Place"
            autoComplete="off"
          />
        </div>
        <button className="btn btn-secondary" type="submit" disabled={status.loading || area.trim().length < 2}>
          {status.loading ? <Loader2 size={16} className="spin" aria-hidden="true" /> : 'Set'}
        </button>
        <button type="button" className="btn btn-ghost" onClick={useDevice} disabled={status.loading}>
          <Crosshair size={16} aria-hidden="true" /> Use my location
        </button>
      </form>
      <p className="location-status" aria-live="polite">
        {status.error ? (
          <span className="text-bad">{status.error}</span>
        ) : location ? (
          <>
            Showing results near <strong>{location.label}</strong>
          </>
        ) : (
          'Set a location to see distances.'
        )}
      </p>
    </div>
  );
}

import { describe, expect, it } from 'vitest';
import { hostOf, km, money, timeAgo } from '../services/format.js';

describe('format helpers', () => {
  it('formats money and handles null', () => {
    expect(money(30)).toMatch(/30/);
    expect(money(null)).toBeNull();
  });
  it('relative times', () => {
    const now = Date.parse('2026-10-18T12:00:00Z');
    expect(timeAgo('2026-10-18T11:30:00Z', now)).toBe('30 min ago');
    expect(timeAgo('2026-10-10T12:00:00Z', now)).toBe('8 days ago');
    expect(timeAgo(null, now)).toBe('unknown time');
    expect(timeAgo('garbage', now)).toBe('unknown time');
  });
  it('hosts and distances', () => {
    expect(hostOf('https://www.example.com/a')).toBe('example.com');
    expect(km(0.4)).toBe('400 m');
    expect(km(2.345)).toBe('2.3 km');
    expect(km(null)).toBeNull();
  });
});

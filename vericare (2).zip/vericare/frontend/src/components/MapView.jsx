import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

// OpenStreetMap tiles. CircleMarkers avoid Leaflet's default image-icon path issues with bundlers.
export default function MapView({ center, points = [] }) {
  if (!center) return null;
  return (
    <div className="map-wrap">
      <MapContainer center={[center.latitude, center.longitude]} zoom={12} scrollWheelZoom={false} className="map">
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <CircleMarker center={[center.latitude, center.longitude]} radius={8} pathOptions={{ color: '#2563eb', fillOpacity: 0.9 }}>
          <Popup>{center.label}</Popup>
        </CircleMarker>
        {points
          .filter((p) => p.latitude != null && p.longitude != null)
          .map((p) => (
            <CircleMarker
              key={p.id}
              center={[p.latitude, p.longitude]}
              radius={7}
              pathOptions={{ color: p.service_type === 'hospital' ? '#dc2626' : '#0d9488', fillOpacity: 0.75 }}
            >
              <Popup>
                <strong>{p.name}</strong>
                <br />
                {p.is_demo ? 'Demo record (fictional)' : 'OpenStreetMap data'} · availability not verified
              </Popup>
            </CircleMarker>
          ))}
      </MapContainer>
    </div>
  );
}

import { Bot, Database, Lock, ShieldCheck } from 'lucide-react';

const ITEMS = [
  {
    icon: ShieldCheck,
    title: 'Trust-first by design',
    body: 'VeriCare never says a medicine is in stock, a hospital has beds, or a price is current without evidence. When we don’t know, we say “unconfirmed”.',
  },
  {
    icon: Bot,
    title: 'Live lookups with TinyFish',
    body: 'An AI browser agent visits a permitted pharmacy website and reads only what is visibly shown. Results are validated before you see them, and “In stock” text on a website is shown as text — not as a confirmation.',
  },
  {
    icon: Database,
    title: 'Clear about demo data',
    body: 'This prototype ships with fictional pharmacies, prices and hospitals so you can try it safely. Every one of them is labelled “Demo”.',
  },
  {
    icon: Lock,
    title: 'Secrets stay on the server',
    body: 'API keys live only in the backend’s private .env file. The browser talks to our own API and never sees them.',
  },
];

export default function About() {
  return (
    <div className="container page narrow">
      <header className="page-head">
        <h1>About VeriCare</h1>
        <p className="lead">
          In a hurry, people waste time travelling to pharmacies that are out of stock or hospitals that can’t help.
          VeriCare puts emergency help and medicine search in one place — and is honest about what it actually knows.
        </p>
      </header>
      <div className="about-grid">
        {ITEMS.map(({ icon: Icon, title, body }) => (
          <div className="card about-item" key={title}>
            <Icon size={24} aria-hidden="true" className="step-icon" />
            <h2>{title}</h2>
            <p>{body}</p>
          </div>
        ))}
      </div>
      <div className="card about-item">
        <h2>What VeriCare is not</h2>
        <p>
          It is not a doctor, pharmacist or emergency service. It does not recommend doses or tell you to switch
          medicines. In an emergency, call <a href="tel:112">112</a>.
        </p>
      </div>
    </div>
  );
}

import { AlertTriangle, CheckCircle2, CircleHelp, Clock, Database, Globe, Inbox, Loader2, ShieldAlert, XCircle } from 'lucide-react';

const STOCK = {
  confirmed: { cls: 'ok', icon: CheckCircle2, label: 'Availability recently confirmed' },
  unconfirmed: { cls: 'neutral', icon: CircleHelp, label: 'Stock unconfirmed' },
  expired: { cls: 'warn', icon: Clock, label: 'Confirmation expired' },
  unable_to_verify: { cls: 'bad', icon: XCircle, label: 'Unable to verify' },
};

export function StockBadge({ stock }) {
  const s = STOCK[stock?.code] || STOCK.unconfirmed;
  const Icon = s.icon;
  return (
    <span className={`badge badge-${s.cls}`}>
      <Icon size={14} aria-hidden="true" />
      {s.label}
      {stock?.is_demo && stock?.code !== 'unconfirmed' && <span className="badge-sub">demo</span>}
    </span>
  );
}

export function SourceTag({ demo, live, host }) {
  if (demo)
    return (
      <span className="tag tag-demo" title="Fictional record seeded for the demo">
        <Database size={12} aria-hidden="true" /> Demo data
      </span>
    );
  if (live)
    return (
      <span className="tag tag-live" title="Retrieved from the website just now">
        <Globe size={12} aria-hidden="true" /> Live · {host}
      </span>
    );
  return null;
}

export function FreshnessTag({ freshness }) {
  if (freshness === 'possibly_outdated')
    return (
      <span className="tag tag-warn">
        <AlertTriangle size={12} aria-hidden="true" /> Price may be outdated
      </span>
    );
  if (freshness === 'unknown') return <span className="tag tag-warn">Price time unknown</span>;
  return null;
}

export function Loading({ label = 'Loading…' }) {
  return (
    <div className="state" role="status" aria-live="polite">
      <Loader2 className="spin" size={26} aria-hidden="true" />
      <p>{label}</p>
    </div>
  );
}

export function Empty({ title, children }) {
  return (
    <div className="state">
      <Inbox size={28} aria-hidden="true" />
      <p className="state-title">{title}</p>
      {children && <p className="state-body">{children}</p>}
    </div>
  );
}

export function ErrorState({ title = 'Something went wrong', message, action }) {
  return (
    <div className="state state-error" role="alert">
      <ShieldAlert size={28} aria-hidden="true" />
      <p className="state-title">{title}</p>
      {message && <p className="state-body">{message}</p>}
      {action}
    </div>
  );
}

export function Notice({ tone = 'info', icon: Icon = AlertTriangle, children }) {
  return (
    <div className={`notice notice-${tone}`}>
      <Icon size={18} aria-hidden="true" />
      <div>{children}</div>
    </div>
  );
}

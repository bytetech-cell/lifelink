"""Seed fictional demo data.

Every record here is invented for the demo and marked is_demo=True. Names carry
"(Demo)" and phone numbers use an obviously fake 0000 pattern so nothing can be
mistaken for a real business. Timestamps are relative to "now" so the stock
statuses show the full range (confirmed, expired, unconfirmed...) whenever the
app starts.

Run directly to rebuild:  python seed.py
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from database import SessionLocal, init_db, utcnow
from models import (
    DataSource,
    EmergencyService,
    Medicine,
    Pharmacy,
    PharmacyListing,
    StockConfirmation,
)
from services.verification_service import expiry_for

PHARMACIES = [
    # key, name, address, lat, lng, phone
    ("lotus", "Lotus Wellness Pharmacy (Demo)", "Block A, Connaught Place area, New Delhi (fictional)", 28.6330, 77.2195, "+91-00000-00101"),
    ("riverside", "Riverside Chemists (Demo)", "Karol Bagh market area, New Delhi (fictional)", 28.6500, 77.1925, "+91-00000-00102"),
    ("northstar", "NorthStar Medicals (Demo)", "Near Rajiv Chowk, New Delhi (fictional)", 28.6285, 77.2140, "+91-00000-00103"),
    ("greenleaf", "GreenLeaf Pharmacy (Demo)", "Saket area, New Delhi (fictional)", 28.5260, 77.2100, "+91-00000-00104"),
    ("citycare", "CityCare Drug Store (Demo)", "Lajpat Nagar area, New Delhi (fictional)", 28.5690, 77.2410, "+91-00000-00105"),
]

MEDICINES = [
    # key, name, ingredient, strength, form
    ("para500", "Paracip-Demo 500", "Paracetamol", "500 mg", "Tablet"),
    ("fever500", "FeverEase-Demo 500", "Paracetamol", "500 mg", "Tablet"),
    ("para650", "Paracip-Demo 650", "Paracetamol", "650 mg", "Tablet"),
    ("parasyr", "Paracip-Demo Syrup", "Paracetamol", "125 mg/5 ml", "Syrup"),
    ("amox500", "Amoxi-Demo 500", "Amoxicillin", "500 mg", "Capsule"),
    ("amoxclav", "AmoxClav-Demo 625", "Amoxicillin + Clavulanic Acid", "500 mg + 125 mg", "Tablet"),
    ("cetri10", "Cetri-Demo 10", "Cetirizine", "10 mg", "Tablet"),
    ("allerfree", "AllerFree-Demo", "Cetirizine", None, "Tablet"),  # incomplete on purpose
    ("metfo500", "Metfo-Demo 500", "Metformin", "500 mg", "Tablet"),
]

LISTINGS = [
    # pharmacy, medicine, product name, pack, unit, price, price_days_ago
    ("lotus", "para500", "Paracip-Demo 500 Tablet", 15, "tablets", 32.0, 1),
    ("riverside", "para500", "Paracip-Demo 500 Tablet", 15, "tablets", 30.0, 2),
    ("greenleaf", "para500", "Paracip-Demo 500 Tablet", 15, "tablets", 24.0, 3),   # cheapest, unconfirmed, far
    ("northstar", "fever500", "FeverEase-Demo 500 Tablet", 10, "tablets", 21.0, 1),
    ("citycare", "fever500", "FeverEase-Demo 500 Tablet", 10, "tablets", 19.5, 12),  # stale price
    ("lotus", "para650", "Paracip-Demo 650 Tablet", 15, "tablets", 34.0, 2),
    ("riverside", "parasyr", "Paracip-Demo Syrup 60 ml", 60, "ml", 45.0, 4),
    ("northstar", "amox500", "Amoxi-Demo 500 Capsule", 10, "capsules", 98.0, 1),
    ("greenleaf", "amoxclav", "AmoxClav-Demo 625 Tablet", 10, "tablets", 210.0, 2),
    ("lotus", "cetri10", "Cetri-Demo 10 Tablet", 10, "tablets", 18.0, 1),
    ("citycare", "allerfree", "AllerFree-Demo Tablet", None, None, 25.0, 5),       # no pack size -> no unit price
    ("riverside", "metfo500", "Metfo-Demo 500 Tablet", 20, "tablets", 40.0, 3),
]

CONFIRMATIONS = [
    # pharmacy, product name, status, minutes ago (None = no confirmation timestamps)
    ("lotus", "Paracip-Demo 500 Tablet", "in_stock", 25),
    ("riverside", "Paracip-Demo 500 Tablet", "in_stock", 70),
    ("northstar", "FeverEase-Demo 500 Tablet", "in_stock", 200),      # expired (> 2 h)
    ("citycare", "FeverEase-Demo 500 Tablet", "unable_to_verify", 40),
    ("northstar", "Amoxi-Demo 500 Capsule", "in_stock", 15),
    ("lotus", "Cetri-Demo 10 Tablet", "out_of_stock", 30),
]

HOSPITALS = [
    ("Sunrise City Hospital (Demo)", "hospital", "Connaught Place area, New Delhi (fictional)", 28.6350, 77.2120, "+91-00000-00201", True),
    ("Yamuna General Hospital (Demo)", "hospital", "Karol Bagh area, New Delhi (fictional)", 28.6560, 77.1880, "+91-00000-00202", True),
    ("Lakeside Multispeciality (Demo)", "hospital", "Saket area, New Delhi (fictional)", 28.5230, 77.2050, "+91-00000-00203", True),
    ("Neighbourhood Health Clinic (Demo)", "clinic", "Lajpat Nagar area, New Delhi (fictional)", 28.5660, 77.2450, None, False),
    ("Metro Ambulance Point (Demo)", "ambulance", "Near Rajiv Chowk, New Delhi (fictional)", 28.6300, 77.2180, "+91-00000-00205", None),
]


def clear_demo(db: Session) -> None:
    demo_listing_ids = select(PharmacyListing.id).where(PharmacyListing.is_demo.is_(True))
    db.execute(delete(StockConfirmation).where(StockConfirmation.listing_id.in_(demo_listing_ids)))
    db.execute(delete(PharmacyListing).where(PharmacyListing.is_demo.is_(True)))
    db.execute(delete(Medicine).where(Medicine.is_demo.is_(True)))
    db.execute(delete(Pharmacy).where(Pharmacy.is_demo.is_(True)))
    db.execute(delete(EmergencyService).where(EmergencyService.is_demo.is_(True)))
    db.execute(delete(DataSource).where(DataSource.is_demo.is_(True)))
    db.commit()


def seed_demo(db: Session) -> None:
    """Replace all demo records with a fresh set (timestamps relative to now)."""
    clear_demo(db)
    now = utcnow()
    src = DataSource(kind="demo_seed", name="VeriCare demo data (fictional)", url=None, is_demo=True)
    db.add(src)
    db.flush()

    ph = {}
    for key, name, addr, lat, lng, phone in PHARMACIES:
        ph[key] = Pharmacy(name=name, address=addr, latitude=lat, longitude=lng, phone=phone, is_demo=True)
        db.add(ph[key])
    med = {}
    for key, name, ing, strength, form in MEDICINES:
        med[key] = Medicine(name=name, active_ingredient=ing, strength=strength, dosage_form=form, is_demo=True)
        db.add(med[key])
    db.flush()

    listing_by = {}
    for pkey, mkey, pname, pack, unit, price, days in LISTINGS:
        li = PharmacyListing(
            pharmacy_id=ph[pkey].id, medicine_id=med[mkey].id, product_name=pname,
            pack_size=pack, pack_unit=unit, price=price, currency="INR", product_url=None,
            price_observed_at=now - timedelta(days=days), source_id=src.id, is_demo=True,
        )
        db.add(li)
        listing_by[(pkey, pname)] = li
    db.flush()

    for pkey, pname, status, mins in CONFIRMATIONS:
        li = listing_by[(pkey, pname)]
        confirmed_at = now - timedelta(minutes=mins)
        db.add(StockConfirmation(
            pharmacy_id=li.pharmacy_id, listing_id=li.id, status=status,
            confirmation_source="demo_seed", confirmed_by="Demo pharmacy staff (fictional)",
            confirmed_at=confirmed_at, expires_at=expiry_for(confirmed_at),
            note="Fictional demo confirmation", is_demo=True,
        ))

    for i, (name, stype, addr, lat, lng, phone, er) in enumerate(HOSPITALS):
        db.add(EmergencyService(
            name=name, service_type=stype, address=addr, latitude=lat, longitude=lng, phone=phone,
            has_emergency_department=er, availability_verified=False,
            last_checked_at=now - timedelta(hours=3 + i), source_id=src.id, is_demo=True,
        ))
    db.commit()


if __name__ == "__main__":
    init_db()
    with SessionLocal() as session:
        seed_demo(session)
    print("Demo data seeded.")

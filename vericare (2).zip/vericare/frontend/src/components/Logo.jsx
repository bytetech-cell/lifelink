export function LogoMark({ size = 34 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" className="logo-mark">
      <defs>
        <linearGradient id="vc-shield" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0d9488" />
          <stop offset="1" stopColor="#2563eb" />
        </linearGradient>
      </defs>
      <path d="M24 3 6 9.5v12.8C6 33.6 13.7 42.4 24 45c10.3-2.6 18-11.4 18-22.7V9.5L24 3z" fill="url(#vc-shield)" />
      <path
        d="M15.5 24.5l6 6 11-12"
        fill="none"
        stroke="#fff"
        strokeWidth="4.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function Logo({ withTagline = false }) {
  return (
    <span className="logo">
      <LogoMark />
      <span className="logo-text">
        <span className="logo-word">
          Veri<span>Care</span>
        </span>
        {withTagline && <span className="logo-tag">Find help. Find medicine. Trust what’s verified.</span>}
      </span>
    </span>
  );
}

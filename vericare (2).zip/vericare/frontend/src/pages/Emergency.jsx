import { lazy, Suspense, useEffect, useState } from 'react';
import { Ambulance, Building2, Navigation, Phone, Search, Siren, Stethoscope } from 'lucide-react';
import { api } from '../services/api.js';
import { useLocation } from '../services/location.jsx';
import { fullTime, km, timeAgo } from '../services/format.js';
import { Empty, ErrorState, Loading, Notice, SourceTag } from '../components/Status.jsx';

const MapView = lazy(() => import('../components/MapView.jsx'));

const TYPE_ICON = { hospital: Building2, clinic: Stethoscope, ambulance: Ambulance };

export default function Emergency() {
  const { location, setLocation, useDevice } = useLocation();
  const [area, setArea] = useState('');
  const [state, setState] = useState({ loading: false, error: null, data: null, mode: null });

  async function load(params) {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const r = await api.emergencyNearby(params);
      setState({ loading: false, error: null, data: r.data, mode: r.meta.source_mode });
      if (params.area) setLocation(r.data.location);
    } catch (e) {
      setState({ loading: false, error: e.message, data: null, mode: null });
    }
  }

  useEffect(() => {
    if (location) load({ lat: location.latitude, lng: location.longitude });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location?.latitude, location?.longitude]);

  const submit = (e) => {
    e.preventDefault();
    if (area.trim().length >= 2) load({ area: area.trim() });
  };

  const num = state.data?.emergency_number;

  return (
    <div className="container page">
      <section className="sos-banner" aria-label="Emergency call">
        <div>
          <p className="sos-kicker">
            <Siren size={16} aria-hidden="true" /> Life-threatening emergency?
          </p>
          <h1>Call 112 now</h1>
          <p>India’s national emergency number connects police, fire and ambulance. Ambulance: 108 in most states.</p>
        </div>
        <div className="sos-actions">
          <a href="tel:112" className="btn btn-sos">
            <Phone size={20} aria-hidden="true" /> Call 112
          </a>
          <a href="tel:108" className="btn btn-sos-outline">
            <Ambulance size={18} aria-hidden="true" /> Ambulance 108
          </a>
        </div>
      </section>

      <div className="card search-panel">
        <form className="search-row" onSubmit={submit}>
          <label htmlFor="em-area" className="sr-only">
            Area
          </label>
          <div className="input-icon grow">
            <Search size={18} aria-hidden="true" />
            <input id="em-area" value={area} onChange={(e) => setArea(e.target.value)} placeholder="Area, e.g. Saket or Karol Bagh" />
          </div>
          <button className="btn btn-primary" type="submit" disabled={area.trim().length < 2 || state.loading}>
            Find nearby care
          </button>
          <button type="button" className="btn btn-ghost" onClick={useDevice}>
            <Navigation size={16} aria-hidden="true" /> Use my location
          </button>
        </form>
        {location && <p className="location-status">Near <strong>{location.label}</strong></p>}
      </div>

      {state.loading && <Loading label="Finding nearby hospitals…" />}
      {state.error && <ErrorState title="Could not load nearby services" message={state.error} />}
      {!state.loading && !state.error && !state.data && (
        <Empty title="Enter an area or share your location">We will list nearby hospitals with directions.</Empty>
      )}

      {state.data && !state.loading && (
        <>
          <Notice tone="warn">
            <strong>Availability is not verified.</strong> {state.data.notice}
            {state.mode === 'demo' && <> These are fictional demo records.</>}
            {state.mode === 'live_osm' && <> Data from OpenStreetMap contributors.</>}
          </Notice>
          <div className="emergency-grid">
            <Suspense fallback={<div className="map-wrap map-loading">Loading map…</div>}>
              <MapView center={state.data.location} points={state.data.results} />
            </Suspense>
            <div className="listing-stack">
              {state.data.results.length === 0 && <Empty title="No services found nearby">Call {num?.primary || 'your local emergency number'}.</Empty>}
              {state.data.results.map((s) => {
                const Icon = TYPE_ICON[s.service_type] || Building2;
                return (
                  <article className="card er-card" key={s.id}>
                    <div className="er-head">
                      <span className={`er-icon er-${s.service_type}`}>
                        <Icon size={20} aria-hidden="true" />
                      </span>
                      <div>
                        <h3>{s.name}</h3>
                        <p className="muted small">
                          <span className="er-type">{s.service_type}</span>
                          {s.distance_km !== null && <> · {km(s.distance_km)}</>}
                          {s.has_emergency_department === true && <> · lists an emergency department</>}
                        </p>
                      </div>
                      <SourceTag demo={s.is_demo} live={!s.is_demo} host="OpenStreetMap" />
                    </div>
                    {s.address && <p className="small">{s.address}</p>}
                    <span className="badge badge-neutral">{s.availability_label}</span>
                    <p className="muted tiny" title={fullTime(s.last_checked_at)}>
                      Source: {s.source?.name || 'unknown'} · last checked {timeAgo(s.last_checked_at)}
                    </p>
                    <div className="listing-actions row">
                      {s.phone && !s.is_demo ? (
                        <a className="btn btn-primary btn-sm" href={`tel:${s.phone.replace(/[^\d+]/g, '')}`}>
                          <Phone size={14} aria-hidden="true" /> Call
                        </a>
                      ) : (
                        <span className="muted tiny">{s.phone ? `${s.phone} (demo, not real)` : 'No phone listed'}</span>
                      )}
                      {s.directions_url && (
                        <a className="btn btn-ghost btn-sm" href={s.directions_url} target="_blank" rel="noopener noreferrer">
                          <Navigation size={14} aria-hidden="true" /> Directions
                        </a>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

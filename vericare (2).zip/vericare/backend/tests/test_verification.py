from datetime import datetime, timedelta
from types import SimpleNamespace

from services.verification_service import current_stock_status, evaluate_confirmation, rank_urgent

NOW = datetime(2026, 10, 18, 12, 0)


def conf(status="in_stock", source="pharmacy_staff", mins_ago=10, expiry_mins=120, missing_times=False):
    confirmed = None if missing_times else NOW - timedelta(minutes=mins_ago)
    return SimpleNamespace(
        id=1, status=status, confirmation_source=source, confirmed_by="x",
        confirmed_at=confirmed, expires_at=None if missing_times else confirmed + timedelta(minutes=expiry_mins),
        created_at=NOW, is_demo=False,
    )


def test_missing_confirmation_is_unconfirmed():
    assert evaluate_confirmation(None, now=NOW) == "unconfirmed"
    s = current_stock_status([], now=NOW)
    assert s["code"] == "unconfirmed" and s["verified"] is False


def test_recent_trusted_confirmation_is_confirmed():
    s = current_stock_status([conf()], now=NOW)
    assert s["code"] == "confirmed" and s["verified"] is True


def test_expired_confirmation():
    s = current_stock_status([conf(mins_ago=130)], now=NOW)
    assert s["code"] == "expired" and s["verified"] is False


def test_incomplete_confirmation_not_verified():
    assert evaluate_confirmation(conf(missing_times=True), now=NOW) == "unconfirmed"


def test_untrusted_source_not_verified():
    # e.g. a TinyFish page visit must never count as a confirmation
    assert evaluate_confirmation(conf(source="tinyfish"), now=NOW) == "unconfirmed"


def test_future_timestamp_not_trusted():
    assert evaluate_confirmation(conf(mins_ago=-60), now=NOW) == "unconfirmed"


def test_out_of_stock_and_unable_to_verify():
    assert evaluate_confirmation(conf(status="out_of_stock"), now=NOW) == "unable_to_verify"
    assert evaluate_confirmation(conf(status="unable_to_verify"), now=NOW) == "unable_to_verify"


def item(name, code, dist, price):
    return {"name": name, "stock": {"code": code}, "distance_km": dist, "unit_price": price}


def test_urgent_ranking_verified_first_by_distance_and_cheap_unconfirmed_separate():
    items = [
        item("cheap-unconfirmed-near", "unconfirmed", 0.5, 0.5),
        item("verified-far", "confirmed", 4.0, 3.0),
        item("verified-near", "confirmed", 1.0, 5.0),
        item("expired", "expired", 0.2, 1.0),
    ]
    r = rank_urgent(items)
    assert [i["name"] for i in r["verified"]] == ["verified-near", "verified-far"]
    assert {i["name"] for i in r["unconfirmed"]} == {"cheap-unconfirmed-near", "expired"}
    assert "call" in r["notice"].lower()


def test_urgent_search_endpoint(client):
    r = client.get("/api/medicines/search", params={"q": "Paracip-Demo 500", "urgent": "true", "lat": 28.6315, "lng": 77.2167})
    data = r.json()["data"]
    assert data["mode"] == "urgent"
    assert all(i["stock"]["code"] == "confirmed" for i in data["verified"])
    # The cheapest demo listing (GreenLeaf, unconfirmed) must NOT be in the verified section.
    assert all("GreenLeaf" not in i["pharmacy"]["name"] for i in data["verified"])
    assert any("GreenLeaf" in i["pharmacy"]["name"] for i in data["unconfirmed"])
    dists = [i["distance_km"] for i in data["verified"]]
    assert dists == sorted(dists)


# ---------- confirmation endpoints

def _a_listing_id(client):
    g = client.get("/api/medicines/search", params={"q": "Metfo"}).json()["data"]["groups"][0]
    return g["listings"][0]["id"]


def test_post_confirmation_disabled_without_token(client):
    r = client.post("/api/confirmations", json={
        "listing_id": 1, "status": "in_stock", "confirmation_source": "pharmacy_staff", "confirmed_by": "Asha"})
    assert r.status_code == 403


def test_post_confirmation_requires_valid_token(client, monkeypatch):
    monkeypatch.setenv("CONFIRMER_TOKEN", "staff-token-123")
    lid = _a_listing_id(client)
    payload = {"listing_id": lid, "status": "in_stock", "confirmation_source": "pharmacy_staff", "confirmed_by": "Asha (staff)"}
    assert client.post("/api/confirmations", json=payload).status_code == 401
    assert client.post("/api/confirmations", json=payload, headers={"X-Confirmer-Token": "wrong"}).status_code == 401

    r = client.post("/api/confirmations", json=payload, headers={"X-Confirmer-Token": "staff-token-123"})
    assert r.status_code == 201
    created = r.json()["data"]
    assert created["evaluated_status"] == "confirmed" and created["is_demo"] is False

    got = client.get(f"/api/confirmations/{created['id']}").json()["data"]
    assert got["expires_at"] == created["expires_at"]

    # Listing now shows verified
    g = client.get("/api/medicines/search", params={"q": "Metfo"}).json()["data"]["groups"][0]
    assert g["listings"][0]["stock"]["verified"] is True


def test_post_confirmation_validation(client, monkeypatch):
    monkeypatch.setenv("CONFIRMER_TOKEN", "t")
    h = {"X-Confirmer-Token": "t"}
    lid = _a_listing_id(client)
    bad_source = {"listing_id": lid, "status": "in_stock", "confirmation_source": "tinyfish", "confirmed_by": "bot"}
    assert client.post("/api/confirmations", json=bad_source, headers=h).status_code == 422
    future = {"listing_id": lid, "status": "in_stock", "confirmation_source": "pharmacy_staff",
              "confirmed_by": "Asha", "confirmed_at": "2099-01-01T00:00:00Z"}
    assert client.post("/api/confirmations", json=future, headers=h).status_code == 422
    missing = {"listing_id": 99999, "status": "in_stock", "confirmation_source": "pharmacy_staff", "confirmed_by": "Asha"}
    assert client.post("/api/confirmations", json=missing, headers=h).status_code == 404
    assert client.get("/api/confirmations/99999").status_code == 404

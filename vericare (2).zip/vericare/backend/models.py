"""SQLAlchemy models. Every record that came from seeding carries is_demo=True."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base, utcnow


class DataSource(Base):
    """Where a piece of information came from (demo seed, TinyFish run, OSM, pharmacy staff...)."""

    __tablename__ = "data_sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[str] = mapped_column(String(40))  # demo_seed | tinyfish | osm | pharmacy_staff
    name: Mapped[str] = mapped_column(String(200))
    url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Medicine(Base):
    __tablename__ = "medicines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    active_ingredient: Mapped[str | None] = mapped_column(String(300), nullable=True, index=True)
    strength: Mapped[str | None] = mapped_column(String(100), nullable=True)  # e.g. "500 mg"
    dosage_form: Mapped[str | None] = mapped_column(String(60), nullable=True)  # tablet, syrup...
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)

    listings: Mapped[list["PharmacyListing"]] = relationship(back_populates="medicine")


class Pharmacy(Base):
    __tablename__ = "pharmacies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    address: Mapped[str | None] = mapped_column(String(300), nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    website: Mapped[str | None] = mapped_column(String(300), nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)

    listings: Mapped[list["PharmacyListing"]] = relationship(back_populates="pharmacy")


class PharmacyListing(Base):
    """A product as offered by one pharmacy, with the price and when it was observed."""

    __tablename__ = "pharmacy_listings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pharmacy_id: Mapped[int] = mapped_column(ForeignKey("pharmacies.id"))
    medicine_id: Mapped[int] = mapped_column(ForeignKey("medicines.id"))
    product_name: Mapped[str] = mapped_column(String(300))
    pack_size: Mapped[int | None] = mapped_column(Integer, nullable=True)  # units per pack
    pack_unit: Mapped[str | None] = mapped_column(String(30), nullable=True)  # tablets, ml...
    price: Mapped[float | None] = mapped_column(Float, nullable=True)
    currency: Mapped[str] = mapped_column(String(8), default="INR")
    product_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    price_observed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    source_id: Mapped[int | None] = mapped_column(ForeignKey("data_sources.id"), nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)

    pharmacy: Mapped[Pharmacy] = relationship(back_populates="listings")
    medicine: Mapped[Medicine] = relationship(back_populates="listings")
    source: Mapped[DataSource | None] = relationship()
    confirmations: Mapped[list["StockConfirmation"]] = relationship(back_populates="listing")


class StockConfirmation(Base):
    """Evidence that a listing was in stock at a given time, from a trusted source."""

    __tablename__ = "stock_confirmations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pharmacy_id: Mapped[int] = mapped_column(ForeignKey("pharmacies.id"))
    listing_id: Mapped[int] = mapped_column(ForeignKey("pharmacy_listings.id"))
    status: Mapped[str] = mapped_column(String(30))  # in_stock | out_of_stock | unable_to_verify
    confirmation_source: Mapped[str] = mapped_column(String(40))  # pharmacy_staff | phone_call | pharmacy_system | demo_seed
    confirmed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    listing: Mapped[PharmacyListing] = relationship(back_populates="confirmations")


class EmergencyService(Base):
    __tablename__ = "emergency_services"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    service_type: Mapped[str] = mapped_column(String(40))  # hospital | clinic | ambulance
    address: Mapped[str | None] = mapped_column(String(300), nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    has_emergency_department: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    availability_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    source_id: Mapped[int | None] = mapped_column(ForeignKey("data_sources.id"), nullable=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)

    source: Mapped[DataSource | None] = relationship()


class LookupLog(Base):
    """One row per live or demo lookup — when it happened, against what, and how it went."""

    __tablename__ = "lookup_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lookup_type: Mapped[str] = mapped_column(String(40))  # medicine_demo | tinyfish | emergency
    query: Mapped[str] = mapped_column(String(300))
    target: Mapped[str | None] = mapped_column(String(300), nullable=True)
    outcome: Mapped[str] = mapped_column(String(40))  # ok | empty | error | timeout | unavailable
    result_count: Mapped[int] = mapped_column(Integer, default=0)
    external_run_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

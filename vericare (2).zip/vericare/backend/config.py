"""Central settings for VeriCare.

All secrets come from environment variables (or a private backend/.env file).
Nothing in this module ever logs or returns the TinyFish API key.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    from dotenv import load_dotenv

    # Load backend/.env first, then a project-root .env as a fallback.
    _here = Path(__file__).resolve().parent
    load_dotenv(_here / ".env")
    load_dotenv(_here.parent / ".env")
except ImportError:  # python-dotenv is optional
    pass


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./vericare.db"))

    # TinyFish — key is read here and only ever placed in an outbound request header.
    tinyfish_api_key: str = field(default_factory=lambda: os.getenv("TINYFISH_API_KEY", "").strip())
    tinyfish_base_url: str = field(
        default_factory=lambda: os.getenv("TINYFISH_BASE_URL", "https://agent.tinyfish.ai").rstrip("/")
    )
    tinyfish_timeout_seconds: int = field(default_factory=lambda: _int("TINYFISH_TIMEOUT_SECONDS", 180))
    tinyfish_max_steps: int = field(default_factory=lambda: _int("TINYFISH_MAX_STEPS", 40))
    # One URL or a comma-separated allow-list of permitted pharmacy sites.
    pharmacy_site_urls_raw: str = field(default_factory=lambda: os.getenv("PHARMACY_SITE_URL", ""))

    # Trust rules
    price_freshness_days: int = field(default_factory=lambda: _int("PRICE_FRESHNESS_DAYS", 7))
    confirmation_expiry_minutes: int = field(default_factory=lambda: _int("CONFIRMATION_EXPIRY_MINUTES", 120))

    # Shared secret that pharmacy staff / trusted systems must send to POST a confirmation.
    confirmer_token: str = field(default_factory=lambda: os.getenv("CONFIRMER_TOKEN", "").strip())

    # Optional live OpenStreetMap lookups (Nominatim + Overpass). Off by default.
    enable_osm_live: bool = field(default_factory=lambda: _bool("ENABLE_OSM_LIVE", False))
    osm_contact_email: str = field(default_factory=lambda: os.getenv("OSM_CONTACT_EMAIL", ""))

    frontend_origins: str = field(
        default_factory=lambda: os.getenv("FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    )

    @property
    def pharmacy_site_urls(self) -> list[str]:
        return [u.strip().rstrip("/") for u in self.pharmacy_site_urls_raw.split(",") if u.strip()]

    @property
    def tinyfish_configured(self) -> bool:
        return bool(self.tinyfish_api_key) and bool(self.pharmacy_site_urls)


def get_settings() -> Settings:
    """Re-read the environment each call so tests can monkeypatch variables."""
    return Settings()

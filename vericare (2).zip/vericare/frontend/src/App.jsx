import { Route, Routes, useLocation as useRouterLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { Footer, Header } from './components/Layout.jsx';
import { LocationProvider } from './services/location.jsx';
import Home from './pages/Home.jsx';
import MedicineFinder from './pages/MedicineFinder.jsx';
import Emergency from './pages/Emergency.jsx';
import About from './pages/About.jsx';
import { Empty } from './components/Status.jsx';

function ScrollTop() {
  const { pathname } = useRouterLocation();
  useEffect(() => window.scrollTo?.(0, 0), [pathname]);
  return null;
}

export default function App() {
  return (
    <LocationProvider>
      <ScrollTop />
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Header />
      <main id="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/medicine" element={<MedicineFinder />} />
          <Route path="/emergency" element={<Emergency />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<div className="container page"><Empty title="Page not found" /></div>} />
        </Routes>
      </main>
      <Footer />
    </LocationProvider>
  );
}

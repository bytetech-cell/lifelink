import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import MedicineFinder from '../pages/MedicineFinder.jsx';
import { LocationProvider } from '../services/location.jsx';

const CONFIG = { ok: true, data: { tinyfish_configured: true, permitted_pharmacy_sites: ['https://pharmacy.example.com'] } };

const listing = (over = {}) => ({
  id: 1,
  product_name: 'Paracip-Demo 500 Tablet',
  medicine: { id: 1, name: 'Paracip-Demo 500', active_ingredient: 'Paracetamol', strength: '500 mg', dosage_form: 'Tablet', is_demo: true },
  pharmacy: { id: 1, name: 'Lotus Wellness Pharmacy (Demo)', phone: '+91-00000-00101', is_demo: true },
  distance_km: 0.3,
  pack_size: 15, pack_unit: 'tablets', price: 30, currency: 'INR', unit_price: 2,
  price_observed_at: '2026-10-17T05:00:00Z', price_freshness: 'fresh', product_url: null,
  source: { kind: 'demo_seed', name: 'VeriCare demo data (fictional)' },
  stock: { code: 'unconfirmed', label: 'Stock unconfirmed', verified: false, is_demo: false, evidence: null },
  is_demo: true,
  ...over,
});

function json(body, status = 200) {
  return Promise.resolve(new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } }));
}

function renderPage() {
  return render(
    <MemoryRouter>
      <LocationProvider>
        <MedicineFinder />
      </LocationProvider>
    </MemoryRouter>,
  );
}

let pending;
beforeEach(() => {
  window.localStorage.clear();
  pending = {};
});
afterEach(() => vi.restoreAllMocks());

function mockFetch(routes) {
  vi.spyOn(global, 'fetch').mockImplementation((url, opts) => {
    const u = String(url);
    for (const [prefix, handler] of Object.entries(routes)) {
      if (u.startsWith(prefix)) return handler(u, opts);
    }
    return json({ ok: false, error: { message: 'not mocked' } }, 404);
  });
}

describe('MedicineFinder', () => {
  it('shows a loading state, then grouped demo results with demo labels', async () => {
    let resolveSearch;
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/medicines/search': () => new Promise((r) => (resolveSearch = r)),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /search demo database/i }));

    expect(screen.getByRole('status')).toHaveTextContent(/searching/i);

    resolveSearch(
      new Response(
        JSON.stringify({
          ok: true,
          data: {
            mode: 'compare',
            medicines: [],
            groups: [{ composition: { active_ingredient: 'Paracetamol', strength: '500 mg', dosage_form: 'Tablet' }, comparable: true, listings: [listing()] }],
          },
          meta: {},
        }),
        { status: 200 },
      ),
    );
    expect(await screen.findByText('Paracip-Demo 500 Tablet')).toBeInTheDocument();
    expect(screen.getAllByText(/demo data/i).length).toBeGreaterThan(0);
    expect(screen.getByText('Stock unconfirmed')).toBeInTheDocument();
    expect(screen.getByText(/₹2(\.00)? \/ unit/)).toBeInTheDocument();
  });

  it('shows an error state when the backend is unreachable', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/medicines/search': () => Promise.reject(new TypeError('Failed to fetch')),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /search demo database/i }));
    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/cannot reach the vericare server/i);
    expect(screen.getByRole('button', { name: /try again/i })).toBeInTheDocument();
  });

  it('shows an empty state when nothing matches', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/medicines/search': () => json({ ok: true, data: { mode: 'compare', medicines: [], groups: [] }, meta: {} }),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'zzz');
    await userEvent.click(screen.getByRole('button', { name: /search demo database/i }));
    expect(await screen.findByText(/no matches for/i)).toBeInTheDocument();
  });

  it('shows a useful message and a labelled demo fallback when live lookup fails', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/tinyfish/medicine-search': () =>
        json({ ok: false, error: { code: 'tinyfish_timeout', message: 'The live lookup took too long and was stopped.', demo_fallback_available: true } }, 504),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /run live lookup/i }));
    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/live lookup failed/i);
    expect(alert).toHaveTextContent(/took too long/i);
    expect(screen.getByRole('button', { name: /show demo data instead/i })).toBeInTheDocument();
  });

  it('labels live results as unconfirmed even when the site says in stock', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/tinyfish/medicine-search': () =>
        json({
          ok: true,
          meta: {},
          data: {
            source_website: 'https://pharmacy.example.com', retrieved_at: new Date().toISOString(), rejected_count: 0, page_note: null,
            notice: 'Stock is NOT confirmed.',
            products: [{ product_name: 'Real Product 500', active_ingredient: null, strength: '500 mg', dosage_form: 'Tablet',
              pack_size_text: '10', pack_size: 10, listed_price: 20, currency: 'INR', unit_price: 2, product_url: 'https://pharmacy.example.com/p/1',
              product_url_rejected: false, visible_stock_text: 'In stock', stock_signal: 'site_says_in_stock', stock_status: 'unconfirmed',
              source_website: 'https://pharmacy.example.com', retrieved_at: new Date().toISOString(), needs_review: true, review_reasons: ['active ingredient not shown'] }],
          },
        }),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /run live lookup/i }));
    expect(await screen.findByText('Real Product 500')).toBeInTheDocument();
    expect(screen.getByText('Stock unconfirmed')).toBeInTheDocument();
    expect(screen.getByText(/not a stock confirmation/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /open product page/i })).toHaveAttribute('href', 'https://pharmacy.example.com/p/1');
  });

  it('explains when live lookup is not configured', async () => {
    mockFetch({ '/api/config': () => json({ ok: true, data: { tinyfish_configured: false, permitted_pharmacy_sites: [] } }) });
    renderPage();
    expect(await screen.findByText(/live lookup is not configured/i)).toBeInTheDocument();
  });

  it('urgent mode shows confirmed and unconfirmed sections plus a call-first notice', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/medicines/search': (u) =>
        u.includes('urgent=true')
          ? json({ ok: true, meta: {}, data: {
              mode: 'urgent', medicines: [], notice: 'Always call the pharmacy to confirm before you travel.',
              verified: [listing({ id: 2, stock: { code: 'confirmed', label: 'x', verified: true, is_demo: true, evidence: null } })],
              unconfirmed: [listing({ id: 3, pharmacy: { id: 3, name: 'GreenLeaf Pharmacy (Demo)', is_demo: true } })] } })
          : json({ ok: true, meta: {}, data: { mode: 'compare', medicines: [], groups: [] } }),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /search demo database/i }));
    await userEvent.click(screen.getByRole('switch'));
    expect(await screen.findByText(/recently confirmed \(1\)/i)).toBeInTheDocument();
    expect(screen.getByText(/not confirmed — call first \(1\)/i)).toBeInTheDocument();
    expect(screen.getByText(/always call the pharmacy/i)).toBeInTheDocument();
  });

  it('verify stock dialog never marks stock verified', async () => {
    mockFetch({
      '/api/config': () => json(CONFIG),
      '/api/medicines/search': () => json({ ok: true, meta: {}, data: { mode: 'compare', medicines: [],
        groups: [{ composition: {}, comparable: true, listings: [listing()] }] } }),
    });
    renderPage();
    await userEvent.type(screen.getByLabelText('Medicine name'), 'paracetamol');
    await userEvent.click(screen.getByRole('button', { name: /search demo database/i }));
    await userEvent.click(await screen.findByRole('button', { name: /verify stock/i }));
    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveTextContent(/does not mark the medicine as available/i);
    expect(dialog).toHaveTextContent(/fictional demo pharmacy/i);
    await userEvent.click(screen.getAllByRole('button', { name: /^close$/i })[0]);
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(screen.getByText('Stock unconfirmed')).toBeInTheDocument();
  });
});

"""TinyFish web-automation integration (backend only).

Uses TinyFish's documented HTTP API:
    POST {TINYFISH_BASE_URL}/v1/automation/run
    Header:  X-API-Key: <key>
    Body:    {"url": ..., "goal": ..., "agent_config": {...}, "output_schema": {...}}
    Reply:   {"status": "COMPLETED"|"FAILED"|..., "run_id": ..., "result": {...} | null,
              "error": {"message": ..., "category": ...} | null, "num_of_steps": int}
(Verified against docs.tinyfish.ai and the official `tinyfish` Python SDK v0.9.0,
which posts to the same path with the same header.)

Trust rules enforced here:
  * Only extract what is visibly on the page; unknown fields are null.
  * Every product is validated with Pydantic; invalid ones are dropped and counted.
  * Product URLs must be http(s) and on the same site that was searched.
  * Visible stock text is passed through as text only. It never becomes a confirmation.
  * The API key is never logged, returned or sent anywhere except the TinyFish header.
"""
from __future__ import annotations

import logging
import time
import urllib.robotparser
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from config import Settings, get_settings
from services.medicine_service import unit_price

log = logging.getLogger("vericare.tinyfish")

RUN_PATH = "/v1/automation/run"


class TinyFishError(Exception):
    """Base error with a safe, user-facing message and an HTTP status for the API layer."""

    http_status = 502
    code = "tinyfish_error"

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class TinyFishNotConfigured(TinyFishError):
    http_status = 503
    code = "tinyfish_not_configured"


class TinyFishTimeout(TinyFishError):
    http_status = 504
    code = "tinyfish_timeout"


class SiteNotAllowed(TinyFishError):
    http_status = 400
    code = "site_not_allowed"


# ------------------------------------------------------------------ schemas

OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "products": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "product_name": {"type": ["string", "null"]},
                    "active_ingredient": {"type": ["string", "null"]},
                    "strength": {"type": ["string", "null"]},
                    "dosage_form": {"type": ["string", "null"]},
                    "pack_size": {"type": ["string", "null"]},
                    "listed_price": {"type": ["string", "null"]},
                    "currency": {"type": ["string", "null"]},
                    "product_url": {"type": ["string", "null"]},
                    "visible_stock_text": {"type": ["string", "null"]},
                },
                "required": ["product_name"],
            },
        },
        "page_note": {"type": ["string", "null"]},
    },
    "required": ["products"],
}


def build_goal(medicine_name: str) -> str:
    return (
        f'Search this pharmacy website for the medicine "{medicine_name}" using the site\'s own search box. '
        "Look at up to 5 relevant products in the search results (open a product page only if details are not on the results page). "
        "For each product, extract ONLY what is visibly written on the page: product_name, active_ingredient "
        "(only if explicitly shown as composition/salt/ingredient), strength (e.g. '500 mg'), dosage_form "
        "(tablet, capsule, syrup...), pack_size (e.g. 'strip of 10 tablets'), listed_price exactly as shown, currency, "
        "the full product_url, and visible_stock_text (exact text such as 'In stock', 'Out of stock', 'Only 2 left'). "
        "Use null for anything not visibly shown. Do NOT guess, infer or fill in values. "
        "Do NOT log in, add to cart, check out, or solve any CAPTCHA; if the site requires login or a CAPTCHA, stop and "
        "explain this in page_note. Return JSON: {\"products\": [...], \"page_note\": string or null}."
    )


class RawProduct(BaseModel):
    """What we accept from TinyFish. Extra keys are ignored."""

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    product_name: str = Field(min_length=1, max_length=300)
    active_ingredient: str | None = Field(default=None, max_length=300)
    strength: str | None = Field(default=None, max_length=100)
    dosage_form: str | None = Field(default=None, max_length=80)
    pack_size: str | int | float | None = None
    listed_price: str | int | float | None = None
    currency: str | None = Field(default=None, max_length=8)
    product_url: str | None = Field(default=None, max_length=1000)
    visible_stock_text: str | None = Field(default=None, max_length=200)

    @field_validator("active_ingredient", "strength", "dosage_form", "currency", "product_url", "visible_stock_text", mode="before")
    @classmethod
    def blank_to_none(cls, v):
        if isinstance(v, str) and v.strip().lower() in {"", "null", "none", "n/a", "na", "not shown", "unknown"}:
            return None
        return v


class LiveProduct(BaseModel):
    """Validated product returned to the frontend."""

    product_name: str
    active_ingredient: str | None
    strength: str | None
    dosage_form: str | None
    pack_size_text: str | None
    pack_size: int | None
    listed_price: float | None
    listed_price_text: str | None
    currency: str | None
    unit_price: float | None
    product_url: str | None
    product_url_rejected: bool
    visible_stock_text: str | None
    stock_signal: str  # site_says_in_stock | site_says_out_of_stock | no_stock_text
    stock_status: str = "unconfirmed"  # always — page text is not a confirmation
    source_website: str
    retrieved_at: str
    needs_review: bool
    review_reasons: list[str]
    is_demo: bool = False


# ------------------------------------------------------------------ helpers

def validate_site(requested: str | None, settings: Settings) -> str:
    """Return the permitted site to search. Only sites listed in PHARMACY_SITE_URL are allowed."""
    allowed = settings.pharmacy_site_urls
    if not allowed:
        raise TinyFishNotConfigured("No pharmacy website is configured (PHARMACY_SITE_URL).")
    if not requested:
        site = allowed[0]
    else:
        site = requested.strip().rstrip("/")
        if site not in allowed:
            raise SiteNotAllowed("That website is not on the permitted pharmacy list.")
    parsed = urlparse(site)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise SiteNotAllowed("The configured pharmacy URL is not a valid http(s) URL.")
    return site


def _host(url: str) -> str:
    h = (urlparse(url).hostname or "").lower()
    return h[4:] if h.startswith("www.") else h


def safe_product_url(url: str | None, site: str) -> tuple[str | None, bool]:
    """Keep the URL only if it is http(s) and on the searched site (or its subdomain)."""
    if not url:
        return None, False
    url = url.strip()
    if url.startswith("/"):
        url = site.rstrip("/") + url
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None, True
    site_host, url_host = _host(site), _host(url)
    if not (url_host == site_host or url_host.endswith("." + site_host)):
        return None, True
    return url, False


def parse_number(value) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if value >= 0 else None
    import re

    text = str(value).replace(",", "")
    m = re.search(r"(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None


def parse_pack_size(value) -> int | None:
    n = parse_number(value)
    if n is None or n <= 0 or n != int(n):
        return None
    return int(n)


def stock_signal(text: str | None) -> str:
    if not text:
        return "no_stock_text"
    t = text.lower()
    if any(k in t for k in ("out of stock", "unavailable", "sold out", "not available", "notify me")):
        return "site_says_out_of_stock"
    if any(k in t for k in ("in stock", "available", "left", "add to cart")):
        return "site_says_in_stock"
    return "no_stock_text"


def normalize_products(result: Any, site: str, retrieved_at: str) -> tuple[list[LiveProduct], int, str | None]:
    """Validate TinyFish's result. Returns (products, number_rejected, page_note)."""
    if not isinstance(result, dict):
        return [], 0, None
    raw_list = result.get("products")
    page_note = result.get("page_note") if isinstance(result.get("page_note"), str) else None
    if not isinstance(raw_list, list):
        return [], 0, page_note
    products, rejected = [], 0
    for raw in raw_list[:20]:
        if not isinstance(raw, dict):
            rejected += 1
            continue
        try:
            p = RawProduct.model_validate(raw)
        except ValidationError:
            rejected += 1
            continue
        url, url_rejected = safe_product_url(p.product_url, site)
        price = parse_number(p.listed_price)
        pack = parse_pack_size(p.pack_size)
        reasons = []
        if not p.active_ingredient:
            reasons.append("active ingredient not shown")
        if not p.strength:
            reasons.append("strength not shown")
        if not p.dosage_form:
            reasons.append("dosage form not shown")
        if url_rejected:
            reasons.append("product link was off-site or invalid and was removed")
        products.append(
            LiveProduct(
                product_name=p.product_name,
                active_ingredient=p.active_ingredient,
                strength=p.strength,
                dosage_form=p.dosage_form,
                pack_size_text=None if p.pack_size is None else str(p.pack_size),
                pack_size=pack,
                listed_price=price,
                listed_price_text=None if p.listed_price is None else str(p.listed_price),
                currency=p.currency,
                unit_price=unit_price(price, pack),
                product_url=url,
                product_url_rejected=url_rejected,
                visible_stock_text=p.visible_stock_text,
                stock_signal=stock_signal(p.visible_stock_text),
                source_website=site,
                retrieved_at=retrieved_at,
                needs_review=bool(reasons),
                review_reasons=reasons,
            )
        )
    return products, rejected, page_note


async def robots_allows(site: str, timeout: float = 8.0) -> bool | None:
    """True/False from robots.txt for the start URL; None if robots.txt could not be read."""
    robots_url = site.rstrip("/") + "/robots.txt"
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as c:
            r = await c.get(robots_url, headers={"User-Agent": "VeriCareBot/0.1"})
    except httpx.HTTPError:
        return None
    if r.status_code >= 400:
        return None if r.status_code >= 500 else True
    rp = urllib.robotparser.RobotFileParser()
    rp.parse(r.text.splitlines())
    return rp.can_fetch("*", site + "/")


# ------------------------------------------------------------------ main call

async def search_medicine(
    medicine_name: str,
    site_url: str | None = None,
    *,
    client: httpx.AsyncClient | None = None,
    settings: Settings | None = None,
    check_robots: bool = True,
) -> dict:
    """Run one TinyFish automation against a permitted pharmacy site and return validated products."""
    settings = settings or get_settings()
    if not settings.tinyfish_api_key:
        raise TinyFishNotConfigured("Live lookup is not configured. Add TINYFISH_API_KEY to backend/.env.")
    site = validate_site(site_url, settings)

    robots = await robots_allows(site) if check_robots else None
    if robots is False:
        raise SiteNotAllowed("This website's robots.txt does not permit automated access, so VeriCare will not search it.")

    body = {
        "url": site,
        "goal": build_goal(medicine_name),
        "agent_config": {
            "max_steps": settings.tinyfish_max_steps,
            "max_duration_seconds": max(30, settings.tinyfish_timeout_seconds - 10),
        },
        "output_schema": OUTPUT_SCHEMA,
    }
    headers = {"X-API-Key": settings.tinyfish_api_key, "Content-Type": "application/json"}
    timeout = httpx.Timeout(settings.tinyfish_timeout_seconds, connect=15.0)

    started = time.monotonic()
    log.info("TinyFish run starting: site=%s query=%r", _host(site), medicine_name)
    own_client = client is None
    client = client or httpx.AsyncClient(base_url=settings.tinyfish_base_url, timeout=timeout)
    try:
        resp = await client.post(RUN_PATH, json=body, headers=headers, timeout=timeout)
    except httpx.TimeoutException:
        log.warning("TinyFish run timed out after %.1fs", time.monotonic() - started)
        raise TinyFishTimeout("The live lookup took too long and was stopped. Try again, or use demo results.")
    except httpx.HTTPError as exc:
        log.warning("TinyFish network error: %s", type(exc).__name__)
        raise TinyFishError("Could not reach the live lookup service. Check your internet connection.")
    finally:
        if own_client:
            await client.aclose()

    if resp.status_code in (401, 403):
        raise TinyFishError("The live lookup service rejected the API key. Check TINYFISH_API_KEY in backend/.env.")
    if resp.status_code == 402:
        raise TinyFishError("The TinyFish account has no credits left.")
    if resp.status_code == 429:
        raise TinyFishError("Too many live lookups at once. Wait a moment and try again.")
    if resp.status_code >= 400:
        raise TinyFishError(f"The live lookup service returned an error (HTTP {resp.status_code}).")

    try:
        payload = resp.json()
    except ValueError:
        raise TinyFishError("The live lookup service sent a response VeriCare could not read.")
    if not isinstance(payload, dict):
        raise TinyFishError("The live lookup service sent an unexpected response.")

    status = str(payload.get("status") or "").upper()
    run_id = payload.get("run_id") if isinstance(payload.get("run_id"), str) else None
    elapsed = round(time.monotonic() - started, 1)
    log.info("TinyFish run finished: run_id=%s status=%s steps=%s elapsed=%ss", run_id, status, payload.get("num_of_steps"), elapsed)

    if status != "COMPLETED":
        err = payload.get("error") if isinstance(payload.get("error"), dict) else {}
        msg = err.get("message") if isinstance(err.get("message"), str) else None
        raise TinyFishError(
            "The live lookup did not finish" + (f": {msg[:200]}" if msg else ".")
        )

    retrieved_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    products, rejected, page_note = normalize_products(payload.get("result"), site, retrieved_at)
    return {
        "run_id": run_id,
        "source_website": site,
        "retrieved_at": retrieved_at,
        "elapsed_seconds": elapsed,
        "robots_checked": robots is not None,
        "products": [p.model_dump() for p in products],
        "rejected_count": rejected,
        "page_note": page_note,
        "notice": "Live listings show what the website displayed. Stock is NOT confirmed and listed prices may differ at checkout.",
    }

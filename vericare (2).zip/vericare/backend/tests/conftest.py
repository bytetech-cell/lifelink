import os
import sys
import tempfile
from pathlib import Path

import pytest

# Isolated test database and no real credentials — set BEFORE the app is imported.
_tmp = tempfile.mkdtemp(prefix="vericare-test-")
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["TINYFISH_API_KEY"] = ""
os.environ["PHARMACY_SITE_URL"] = ""
os.environ["CONFIRMER_TOKEN"] = ""
os.environ["ENABLE_OSM_LIVE"] = "false"

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient  # noqa: E402

from main import app  # noqa: E402


@pytest.fixture()
def client():
    with TestClient(app) as c:  # runs lifespan -> creates tables + seeds demo data
        yield c

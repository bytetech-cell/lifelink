"""Request validation models (Pydantic v2)."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

_MEDICINE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 \-+./(),%]*$")


class TinyFishSearchRequest(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    medicine_name: str = Field(min_length=2, max_length=80)
    site_url: str | None = Field(default=None, max_length=300)

    @field_validator("medicine_name")
    @classmethod
    def check_name(cls, v: str) -> str:
        if "://" in v or "www." in v.lower():
            raise ValueError("Enter a medicine name, not a link")
        if not _MEDICINE_RE.match(v):
            raise ValueError("Use letters, numbers, spaces and - + . / ( ) , % only")
        return re.sub(r"\s+", " ", v)


class ConfirmationCreate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    listing_id: int = Field(gt=0)
    status: Literal["in_stock", "out_of_stock", "unable_to_verify"]
    confirmation_source: Literal["pharmacy_staff", "phone_call_verified", "pharmacy_system"]
    confirmed_by: str = Field(min_length=2, max_length=120)
    confirmed_at: datetime | None = None
    note: str | None = Field(default=None, max_length=500)

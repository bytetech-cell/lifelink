import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, Phone, X } from 'lucide-react';
import Logo from './Logo.jsx';

const NAV = [
  { to: '/', label: 'Home', end: true },
  { to: '/medicine', label: 'Find Medicine' },
  { to: '/emergency', label: 'Emergency Help' },
  { to: '/about', label: 'About' },
];

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="container header-row">
        <Link to="/" className="brand-link" aria-label="VeriCare home" onClick={() => setOpen(false)}>
          <Logo />
        </Link>
        <nav className={`nav ${open ? 'nav-open' : ''}`} aria-label="Main">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className="nav-link" onClick={() => setOpen(false)}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <a href="tel:112" className="sos-pill" aria-label="Call 112, India emergency number">
          <Phone size={15} aria-hidden="true" /> 112
        </a>
        <button
          className="menu-btn"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-row">
        <Logo />
        <p>
          Hackathon prototype. VeriCare is not a medical service and does not replace emergency services, doctors or
          pharmacists. Records marked <strong>Demo</strong> are fictional.
        </p>
      </div>
    </footer>
  );
}

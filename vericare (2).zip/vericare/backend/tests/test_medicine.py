from datetime import datetime, timedelta

from services.medicine_service import (
    compare_composition,
    normalize_ingredient,
    normalize_strength,
    price_freshness,
    unit_price,
)


# ---------- price per unit

def test_unit_price_basic():
    assert unit_price(30.0, 15) == 2.0
    assert unit_price(19.5, 10) == 1.95


def test_unit_price_missing_or_invalid():
    assert unit_price(None, 10) is None
    assert unit_price(30, None) is None
    assert unit_price(30, 0) is None
    assert unit_price(-5, 10) is None
    assert unit_price("abc", 10) is None
    assert unit_price(float("nan"), 10) is None


# ---------- matching

PARA_500_TAB = {"active_ingredient": "Paracetamol", "strength": "500 mg", "dosage_form": "Tablet"}


def test_same_composition_matches_even_with_different_names_and_formats():
    other = {"active_ingredient": "paracetamol", "strength": "0.5 g", "dosage_form": "tab"}
    assert compare_composition(PARA_500_TAB, other)["match"] == "same"


def test_similar_name_different_strength_is_different():
    other = {**PARA_500_TAB, "strength": "650 mg"}
    result = compare_composition(PARA_500_TAB, other)
    assert result["match"] == "different"
    assert "strength differs" in result["reasons"]


def test_different_dosage_form_is_different():
    other = {**PARA_500_TAB, "dosage_form": "Syrup"}
    assert compare_composition(PARA_500_TAB, other)["match"] == "different"


def test_missing_strength_is_uncertain_not_same():
    other = {**PARA_500_TAB, "strength": None}
    result = compare_composition(PARA_500_TAB, other)
    assert result["match"] == "uncertain"


def test_combination_order_independent_but_not_equal_to_single():
    assert normalize_ingredient("Amoxicillin + Clavulanic Acid") == normalize_ingredient("clavulanic acid, amoxicillin")
    single = {"active_ingredient": "Amoxicillin", "strength": "500 mg", "dosage_form": "Tablet"}
    combo = {"active_ingredient": "Amoxicillin + Clavulanic Acid", "strength": "500 mg + 125 mg", "dosage_form": "Tablet"}
    assert compare_composition(single, combo)["match"] == "different"


def test_strength_units_normalised():
    assert normalize_strength("500 mg") == normalize_strength("0.5g")
    assert normalize_strength("no number") is None


# ---------- freshness

def test_price_freshness_threshold():
    now = datetime(2026, 10, 18, 12, 0)
    assert price_freshness(now - timedelta(days=2), now=now, days=7) == "fresh"
    assert price_freshness(now - timedelta(days=8), now=now, days=7) == "possibly_outdated"
    assert price_freshness(None, now=now) == "unknown"


# ---------- API

def test_search_endpoint_returns_demo_groups(client):
    r = client.get("/api/medicines/search", params={"q": "paracetamol"})
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True and body["meta"]["contains_demo"] is True
    groups = body["data"]["groups"]
    # 500 mg tablets, 650 mg tablets and syrup must be separate groups — never compared together.
    strengths = sorted({(g["composition"]["strength"], g["composition"]["dosage_form"]) for g in groups})
    assert ("500 mg", "Tablet") in strengths and ("650 mg", "Tablet") in strengths
    tab500 = next(g for g in groups if g["composition"]["strength"] == "500 mg")
    assert all(li["is_demo"] for li in tab500["listings"])
    prices = [li["unit_price"] for li in tab500["listings"]]
    assert prices == sorted(prices)  # cheapest per unit first in compare mode


def test_search_flags_stale_price(client):
    r = client.get("/api/medicines/search", params={"q": "FeverEase"})
    listings = r.json()["data"]["groups"][0]["listings"]
    assert {li["price_freshness"] for li in listings} == {"fresh", "possibly_outdated"}


def test_search_incomplete_composition_not_comparable(client):
    r = client.get("/api/medicines/search", params={"q": "cetirizine"})
    groups = r.json()["data"]["groups"]
    incomplete = [g for g in groups if not g["comparable"]]
    assert incomplete and incomplete[0]["review_note"]
    allerfree = incomplete[0]["listings"][0]
    assert allerfree["unit_price"] is None  # no pack size -> no per-unit price


def test_search_empty_and_invalid(client):
    r = client.get("/api/medicines/search", params={"q": "zzznotamedicine"})
    assert r.status_code == 200 and r.json()["meta"]["count"] == 0
    r = client.get("/api/medicines/search", params={"q": "a"})
    assert r.status_code == 422 and r.json()["ok"] is False


def test_alternatives(client):
    search = client.get("/api/medicines/search", params={"q": "Paracip-Demo 500"}).json()
    med_id = next(m["id"] for m in search["data"]["medicines"] if m["name"] == "Paracip-Demo 500")
    r = client.get(f"/api/medicines/{med_id}/alternatives")
    data = r.json()["data"]
    names = [m["name"] for m in data["same_composition"]]
    assert names == ["FeverEase-Demo 500"]  # 650 mg and syrup are NOT alternatives
    assert client.get("/api/medicines/99999/alternatives").status_code == 404


def test_health_and_config_never_leak_key(client, monkeypatch):
    monkeypatch.setenv("TINYFISH_API_KEY", "sk-secret-should-not-appear")
    for path in ("/api/health", "/api/config"):
        r = client.get(path)
        assert r.status_code == 200
        assert "sk-secret-should-not-appear" not in r.text

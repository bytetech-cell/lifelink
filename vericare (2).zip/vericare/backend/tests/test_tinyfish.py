"""TinyFish tests. All network calls are mocked with httpx.MockTransport — no credits used."""
import asyncio
import json

import httpx
import pytest

from config import Settings
from services import tinyfish_service as tf

SITE = "https://pharmacy.example.com"


def settings(**kw):
    base = dict(tinyfish_api_key="test-key", pharmacy_site_urls_raw=SITE, tinyfish_timeout_seconds=60)
    base.update(kw)
    return Settings(**base)


def run(coro):
    return asyncio.run(coro)


def mock_client(handler):
    return httpx.AsyncClient(base_url="https://agent.tinyfish.ai", transport=httpx.MockTransport(handler))


def completed(result):
    return httpx.Response(200, json={"status": "COMPLETED", "run_id": "run_1", "result": result, "error": None, "num_of_steps": 7})


def test_request_shape_and_header():
    seen = {}

    def handler(request: httpx.Request):
        seen["path"] = request.url.path
        seen["key"] = request.headers.get("X-API-Key")
        seen["body"] = json.loads(request.content)
        return completed({"products": []})

    out = run(tf.search_medicine("Paracetamol 500", client=mock_client(handler), settings=settings(), check_robots=False))
    assert seen["path"] == "/v1/automation/run"
    assert seen["key"] == "test-key"
    assert seen["body"]["url"] == SITE and "Paracetamol 500" in seen["body"]["goal"]
    assert "output_schema" in seen["body"]
    assert out["products"] == [] and "test-key" not in json.dumps(out)


def test_missing_fields_become_null_and_flagged():
    result = {"products": [
        {"product_name": "Paracip 500 Tablet", "listed_price": "₹32.50", "pack_size": "strip of 15 tablets",
         "product_url": "/p/paracip-500", "visible_stock_text": None},
        {"product_name": "Mystery item"},  # nearly empty
        {"listed_price": "10"},           # no product name -> rejected
        "not-a-dict",                     # rejected
    ]}
    out = run(tf.search_medicine("paracip", client=mock_client(lambda r: completed(result)), settings=settings(), check_robots=False))
    assert out["rejected_count"] == 2
    p1, p2 = out["products"]
    assert p1["listed_price"] == 32.5 and p1["pack_size"] == 15 and p1["unit_price"] == 2.17
    assert p1["product_url"] == SITE + "/p/paracip-500"
    assert p1["stock_status"] == "unconfirmed" and p1["stock_signal"] == "no_stock_text"
    assert p2["listed_price"] is None and p2["unit_price"] is None and p2["active_ingredient"] is None
    assert p2["needs_review"] is True


def test_in_stock_text_is_never_a_confirmation():
    result = {"products": [{"product_name": "X 10 mg", "visible_stock_text": "In stock"}]}
    out = run(tf.search_medicine("x", client=mock_client(lambda r: completed(result)), settings=settings(), check_robots=False))
    p = out["products"][0]
    assert p["stock_signal"] == "site_says_in_stock"
    assert p["stock_status"] == "unconfirmed"


@pytest.mark.parametrize("url,expected,rejected", [
    ("https://pharmacy.example.com/item/1", "https://pharmacy.example.com/item/1", False),
    ("https://www.pharmacy.example.com/item/1", "https://www.pharmacy.example.com/item/1", False),
    ("https://evil.example.net/phish", None, True),
    ("javascript:alert(1)", None, True),
    ("ftp://pharmacy.example.com/x", None, True),
    ("https://pharmacy.example.com.evil.net/x", None, True),
    (None, None, False),
])
def test_invalid_source_urls(url, expected, rejected):
    assert tf.safe_product_url(url, SITE) == (expected, rejected)


def test_timeout():
    def handler(request):
        raise httpx.ReadTimeout("slow", request=request)

    with pytest.raises(tf.TinyFishTimeout):
        run(tf.search_medicine("x y", client=mock_client(handler), settings=settings(), check_robots=False))


@pytest.mark.parametrize("status,phrase", [(401, "API key"), (402, "credits"), (429, "Too many"), (500, "HTTP 500")])
def test_http_errors(status, phrase):
    with pytest.raises(tf.TinyFishError) as e:
        run(tf.search_medicine("x y", client=mock_client(lambda r: httpx.Response(status, json={})), settings=settings(), check_robots=False))
    assert phrase in e.value.message
    assert "test-key" not in e.value.message


def test_failed_run_and_garbage_response():
    failed = httpx.Response(200, json={"status": "FAILED", "run_id": "r", "result": None,
                                       "error": {"message": "Site blocked automation", "category": "SYSTEM_FAILURE"}, "num_of_steps": 2})
    with pytest.raises(tf.TinyFishError) as e:
        run(tf.search_medicine("x y", client=mock_client(lambda r: failed), settings=settings(), check_robots=False))
    assert "Site blocked automation" in e.value.message

    with pytest.raises(tf.TinyFishError):
        run(tf.search_medicine("x y", client=mock_client(lambda r: httpx.Response(200, text="<html>oops")), settings=settings(), check_robots=False))

    # Result that isn't the expected shape -> empty, not a crash
    out = run(tf.search_medicine("x y", client=mock_client(lambda r: completed("just text")), settings=settings(), check_robots=False))
    assert out["products"] == []


def test_not_configured_and_site_allow_list():
    with pytest.raises(tf.TinyFishNotConfigured):
        run(tf.search_medicine("x y", settings=settings(tinyfish_api_key=""), check_robots=False))
    with pytest.raises(tf.SiteNotAllowed):
        run(tf.search_medicine("x y", site_url="https://other.example.org", settings=settings(), check_robots=False))


def test_endpoint_returns_503_when_not_configured(client):
    r = client.post("/api/tinyfish/medicine-search", json={"medicine_name": "Paracetamol"})
    assert r.status_code == 503
    err = r.json()["error"]
    assert err["code"] == "tinyfish_not_configured" and err["demo_fallback_available"] is True


def test_endpoint_input_validation(client):
    for bad in ({"medicine_name": "x"}, {"medicine_name": "https://evil.com"}, {"medicine_name": "<script>"}, {}):
        r = client.post("/api/tinyfish/medicine-search", json=bad)
        assert r.status_code == 422, bad


def test_endpoint_success_with_mock(client, monkeypatch):
    async def fake(name, site_url=None):
        return {"run_id": "r1", "source_website": SITE, "retrieved_at": "2026-10-18T05:00:00Z", "elapsed_seconds": 1.0,
                "robots_checked": True, "products": [], "rejected_count": 0, "page_note": None, "notice": "n"}

    monkeypatch.setattr(tf, "search_medicine", fake)
    r = client.post("/api/tinyfish/medicine-search", json={"medicine_name": "Paracetamol"})
    assert r.status_code == 200 and r.json()["meta"]["data_source"] == "tinyfish_live"

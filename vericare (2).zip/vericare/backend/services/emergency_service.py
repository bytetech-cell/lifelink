"""Nearby hospitals / emergency services and simple location lookup.

Sources, in order of preference:
  1. Live OpenStreetMap (Overpass API) — only when ENABLE_OSM_LIVE=true. Community data, labelled unverified.
  2. Local database (seeded demo records, labelled demo).

VeriCare never claims beds, ambulances or specialists are available. Every
result carries availability_verified=False unless a verified record says otherwise.
"""
from __future__ import annotations

import logging

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from config import get_settings
from database import iso, utcnow
from models import EmergencyService
from services.medicine_service import haversine_km

log = logging.getLogger("vericare.emergency")

# Only numbers we are confident about. Others fall back to "call your local emergency number".
EMERGENCY_NUMBERS = {
    "IN": {"primary": "112", "label": "National Emergency Number (India)", "ambulance": "108"},
}

# Named areas for the demo location box (coordinates of public areas, not businesses).
DEMO_AREAS = {
    "connaught place": ("Connaught Place, New Delhi", 28.6315, 77.2167),
    "karol bagh": ("Karol Bagh, New Delhi", 28.6519, 77.1909),
    "saket": ("Saket, New Delhi", 28.5245, 77.2066),
    "dwarka": ("Dwarka, New Delhi", 28.5921, 77.0460),
    "rohini": ("Rohini, Delhi", 28.7383, 77.0822),
    "lajpat nagar": ("Lajpat Nagar, New Delhi", 28.5677, 77.2433),
    "noida": ("Noida Sector 18", 28.5708, 77.3261),
    "gurgaon": ("Gurugram, Cyber City", 28.4950, 77.0895),
    "manipal": ("Manipal, Karnataka", 13.3525, 74.7928),
}


def directions_url(lat, lng, from_lat=None, from_lng=None) -> str | None:
    if lat is None or lng is None:
        return None
    if from_lat is not None and from_lng is not None:
        return f"https://www.openstreetmap.org/directions?route={from_lat}%2C{from_lng}%3B{lat}%2C{lng}"
    return f"https://www.openstreetmap.org/?mlat={lat}&mlon={lng}#map=17/{lat}/{lng}"


def _osm_headers() -> dict:
    s = get_settings()
    contact = f" ({s.osm_contact_email})" if s.osm_contact_email else ""
    return {"User-Agent": f"VeriCare-hackathon-prototype/0.1{contact}"}


async def geocode(query: str) -> dict | None:
    """Resolve an area name to coordinates: demo area list first, then Nominatim if enabled."""
    q = query.strip().lower()
    for key, (label, lat, lng) in DEMO_AREAS.items():
        if key in q or q in key:
            return {"label": label, "latitude": lat, "longitude": lng, "source": "VeriCare area list"}
    if not get_settings().enable_osm_live:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(
                "https://nominatim.openstreetmap.org/search",
                params={"q": query, "format": "jsonv2", "limit": 1},
                headers=_osm_headers(),
            )
        r.raise_for_status()
        data = r.json()
    except (httpx.HTTPError, ValueError):
        log.warning("Nominatim lookup failed")
        return None
    if not data:
        return None
    top = data[0]
    return {
        "label": top.get("display_name", query)[:120],
        "latitude": float(top["lat"]),
        "longitude": float(top["lon"]),
        "source": "OpenStreetMap Nominatim",
    }


def _service_dict(s: EmergencyService, lat, lng) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "service_type": s.service_type,
        "address": s.address,
        "latitude": s.latitude,
        "longitude": s.longitude,
        "phone": s.phone,
        "has_emergency_department": s.has_emergency_department,
        "distance_km": haversine_km(lat, lng, s.latitude, s.longitude),
        "directions_url": directions_url(s.latitude, s.longitude, lat, lng),
        "availability_verified": bool(s.availability_verified),
        "availability_label": "Availability verified" if s.availability_verified else "Availability not verified — call ahead",
        "last_checked_at": iso(s.last_checked_at),
        "source": {
            "kind": s.source.kind if s.source else None,
            "name": s.source.name if s.source else None,
            "url": s.source.url if s.source else None,
        },
        "is_demo": s.is_demo,
    }


def nearby_from_db(db: Session, lat, lng, radius_km: float = 25, limit: int = 20) -> list[dict]:
    rows = db.execute(select(EmergencyService).options(joinedload(EmergencyService.source))).scalars().all()
    items = [_service_dict(s, lat, lng) for s in rows]
    if lat is not None and lng is not None:
        items = [i for i in items if i["distance_km"] is None or i["distance_km"] <= radius_km]
        items.sort(key=lambda i: (i["distance_km"] is None, i["distance_km"] or 0))
    return items[:limit]


def parse_overpass(data: dict, lat, lng, checked_at: str) -> list[dict]:
    out = []
    for el in (data or {}).get("elements", []):
        tags = el.get("tags") or {}
        name = tags.get("name")
        e_lat = el.get("lat") or (el.get("center") or {}).get("lat")
        e_lng = el.get("lon") or (el.get("center") or {}).get("lon")
        if not name or e_lat is None or e_lng is None:
            continue
        addr = ", ".join(
            p for p in [tags.get("addr:housenumber"), tags.get("addr:street"), tags.get("addr:suburb"), tags.get("addr:city")] if p
        ) or None
        emergency = tags.get("emergency")
        out.append({
            "id": f"osm-{el.get('type')}-{el.get('id')}",
            "name": name,
            "service_type": tags.get("amenity") or tags.get("healthcare") or "hospital",
            "address": addr,
            "latitude": e_lat,
            "longitude": e_lng,
            "phone": tags.get("phone") or tags.get("contact:phone"),
            "has_emergency_department": True if emergency == "yes" else (False if emergency == "no" else None),
            "distance_km": haversine_km(lat, lng, e_lat, e_lng),
            "directions_url": directions_url(e_lat, e_lng, lat, lng),
            "availability_verified": False,
            "availability_label": "Availability not verified — call ahead",
            "last_checked_at": checked_at,
            "source": {"kind": "osm", "name": "OpenStreetMap contributors", "url": f"https://www.openstreetmap.org/{el.get('type')}/{el.get('id')}"},
            "is_demo": False,
        })
    out.sort(key=lambda i: (i["distance_km"] is None, i["distance_km"] or 0))
    return out


async def nearby_live_osm(lat: float, lng: float, radius_m: int = 6000) -> list[dict] | None:
    query = (
        f"[out:json][timeout:20];("
        f'node["amenity"~"hospital|clinic"](around:{radius_m},{lat},{lng});'
        f'way["amenity"~"hospital|clinic"](around:{radius_m},{lat},{lng});'
        f");out center 40;"
    )
    try:
        async with httpx.AsyncClient(timeout=25) as c:
            r = await c.post("https://overpass-api.de/api/interpreter", data={"data": query}, headers=_osm_headers())
        r.raise_for_status()
        data = r.json()
    except (httpx.HTTPError, ValueError):
        log.warning("Overpass lookup failed")
        return None
    return parse_overpass(data, lat, lng, iso(utcnow()))


def emergency_number(country: str = "IN") -> dict:
    info = EMERGENCY_NUMBERS.get(country.upper())
    if info:
        return {**info, "country": country.upper(), "verified": True}
    return {"primary": None, "label": "Call your local emergency number", "country": country.upper(), "verified": False}

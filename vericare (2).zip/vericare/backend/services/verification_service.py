"""Stock-confirmation rules and Urgent Mode ranking.

A listing only shows "Availability recently confirmed" when there is a
confirmation that:
  * came from a trusted source (pharmacy staff, a verified call, a pharmacy system),
  * says the item is in stock,
  * has both a confirmation time and an expiry time, and
  * has not expired yet.
Anything else is "unconfirmed", "expired" or "unable_to_verify". A TinyFish page
visit or a search hit is never a confirmation.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from config import get_settings
from database import iso, utcnow

TRUSTED_SOURCES = {"pharmacy_staff", "phone_call_verified", "pharmacy_system", "demo_seed"}

STATUS_LABELS = {
    "unconfirmed": "Stock unconfirmed",
    "confirmed": "Availability recently confirmed",
    "expired": "Confirmation expired",
    "unable_to_verify": "Unable to verify",
}


def expiry_for(confirmed_at: datetime) -> datetime:
    return confirmed_at + timedelta(minutes=get_settings().confirmation_expiry_minutes)


def evaluate_confirmation(conf, now: datetime | None = None) -> str:
    """Status code for a single confirmation record."""
    now = now or utcnow()
    if conf is None:
        return "unconfirmed"
    if conf.confirmation_source not in TRUSTED_SOURCES:
        return "unconfirmed"
    if conf.status == "unable_to_verify":
        return "unable_to_verify"
    if conf.confirmed_at is None or conf.expires_at is None:
        return "unconfirmed"  # incomplete evidence
    if conf.confirmed_at > now + timedelta(minutes=5):
        return "unconfirmed"  # timestamps from the future are not trusted
    if now >= conf.expires_at:
        return "expired"
    if conf.status == "out_of_stock":
        return "unable_to_verify"  # recent evidence says it is NOT available
    if conf.status == "in_stock":
        return "confirmed"
    return "unconfirmed"


def current_stock_status(confirmations, now: datetime | None = None) -> dict:
    """Pick the most recent confirmation and describe it for the UI."""
    now = now or utcnow()
    latest = None
    for c in confirmations or []:
        if latest is None or (c.confirmed_at or c.created_at) > (latest.confirmed_at or latest.created_at):
            latest = c
    code = evaluate_confirmation(latest, now=now)
    detail = None
    if latest is not None and code != "unconfirmed":
        detail = {
            "confirmation_id": latest.id,
            "source": latest.confirmation_source,
            "confirmed_by": latest.confirmed_by,
            "confirmed_at": iso(latest.confirmed_at),
            "expires_at": iso(latest.expires_at),
            "reported_status": latest.status,
            "is_demo": latest.is_demo,
        }
    return {
        "code": code,
        "label": STATUS_LABELS[code],
        "verified": code == "confirmed",
        "is_demo": bool(latest and latest.is_demo),
        "evidence": detail,
    }


def rank_urgent(items: list[dict]) -> dict:
    """Urgent Mode: verified results first, sorted by distance; everything else separately.

    Price is deliberately ignored for ordering — a cheaper unconfirmed listing must
    never jump ahead of a confirmed one.
    """
    verified = [i for i in items if i["stock"]["code"] == "confirmed"]
    others = [i for i in items if i["stock"]["code"] != "confirmed"]

    def dist(i):
        d = i.get("distance_km")
        return (d is None, d if d is not None else 0)

    verified.sort(key=dist)
    others.sort(key=dist)
    return {
        "verified": verified,
        "unconfirmed": others,
        "notice": "Always call the pharmacy to confirm before you travel.",
    }

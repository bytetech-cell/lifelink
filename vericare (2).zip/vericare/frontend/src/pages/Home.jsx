import { Link } from 'react-router-dom';
import { ArrowRight, BadgeCheck, Clock, FileSearch, Pill, Siren, Link2, AlertTriangle } from 'lucide-react';
import LocationInput from '../components/LocationInput.jsx';
import { Notice } from '../components/Status.jsx';

const STEPS = [
  { icon: FileSearch, title: 'Show the source', body: 'Every price and listing shows where it came from and when it was seen.' },
  { icon: Pill, title: 'Match the real medicine', body: 'Products are compared only when ingredient, strength and form all match — never by name alone.' },
  { icon: BadgeCheck, title: 'Confirm, don’t guess', body: 'A “confirmed” badge needs recent evidence from the pharmacy. A web page visit is not proof.' },
  { icon: Clock, title: 'Let old facts expire', body: 'Stock confirmations expire after 2 hours. Prices older than 7 days are flagged.' },
];

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <p className="eyebrow">Trust-first healthcare search</p>
            <h1>
              Find help. Find medicine.
              <br />
              <span className="grad">Trust what’s verified.</span>
            </h1>
            <p className="lead">
              VeriCare finds nearby medicine and emergency care — and tells you honestly what is confirmed, what is
              not, and where every fact came from.
            </p>
            <LocationInput />
          </div>
          <div className="hero-cards">
            <Link to="/medicine" className="action-card action-medicine">
              <span className="action-icon">
                <Pill size={26} aria-hidden="true" />
              </span>
              <span>
                <span className="action-title">Find Medicine</span>
                <span className="action-body">Compare prices per unit and see verified stock near you.</span>
              </span>
              <ArrowRight className="action-arrow" size={20} aria-hidden="true" />
            </Link>
            <Link to="/emergency" className="action-card action-emergency">
              <span className="action-icon">
                <Siren size={26} aria-hidden="true" />
              </span>
              <span>
                <span className="action-title">Emergency Help</span>
                <span className="action-body">Nearby hospitals, directions and the emergency number — fast.</span>
              </span>
              <ArrowRight className="action-arrow" size={20} aria-hidden="true" />
            </Link>
            <Notice tone="warn" icon={AlertTriangle}>
              <strong>Live availability is not guaranteed.</strong> Always call before you travel. In an emergency,
              call <a href="tel:112">112</a> first.
            </Notice>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">How VeriCare verifies information</h2>
          <p className="section-sub">Four rules that every result on this site follows.</p>
          <div className="steps">
            {STEPS.map(({ icon: Icon, title, body }, i) => (
              <div className="card step" key={title}>
                <span className="step-num">{i + 1}</span>
                <Icon size={22} aria-hidden="true" className="step-icon" />
                <h3>{title}</h3>
                <p>{body}</p>
              </div>
            ))}
          </div>
          <div className="legend card">
            <h3>
              <Link2 size={18} aria-hidden="true" /> What the labels mean
            </h3>
            <ul>
              <li><span className="badge badge-ok">Availability recently confirmed</span> pharmacy confirmed within the last 2 hours</li>
              <li><span className="badge badge-neutral">Stock unconfirmed</span> no trusted confirmation yet</li>
              <li><span className="badge badge-warn">Confirmation expired</span> the last confirmation is too old</li>
              <li><span className="badge badge-bad">Unable to verify</span> the pharmacy could not confirm, or said it is out</li>
              <li><span className="tag tag-demo">Demo data</span> fictional record for this prototype</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}

import { useEffect, useRef, useState } from 'react';
import { Info, Phone, X } from 'lucide-react';
import { api } from '../services/api.js';
import { Empty, ErrorState, Loading } from './Status.jsx';

function Modal({ title, onClose, children }) {
  const ref = useRef(null);
  useEffect(() => {
    ref.current?.focus();
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" tabIndex={-1} ref={ref}>
        <div className="modal-head">
          <h2 id="modal-title">{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={20} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function VerifyStockDialog({ item, onClose }) {
  const ph = item.pharmacy;
  return (
    <Modal title="Verify stock before you go" onClose={onClose}>
      <p>
        Call <strong>{ph.name}</strong> and ask whether <strong>{item.product_name}</strong>
        {item.pack_size ? ` (${item.pack_size} ${item.pack_unit || 'units'})` : ''} is in stock right now.
      </p>
      {ph.is_demo && (
        <p className="notice notice-warn small">
          <Info size={16} aria-hidden="true" /> This is a fictional demo pharmacy. Its phone number is not real.
        </p>
      )}
      <div className="modal-actions">
        {ph.phone && !ph.is_demo ? (
          <a className="btn btn-primary" href={`tel:${ph.phone.replace(/[^\d+]/g, '')}`}>
            <Phone size={16} aria-hidden="true" /> Call {ph.phone}
          </a>
        ) : (
          <button className="btn btn-primary" disabled>
            <Phone size={16} aria-hidden="true" /> {ph.phone ? `${ph.phone} (demo)` : 'No phone listed'}
          </button>
        )}
        <button className="btn btn-ghost" onClick={onClose}>
          Close
        </button>
      </div>
      <p className="muted small">
        Tapping this button does <strong>not</strong> mark the medicine as available. Only pharmacy staff or a trusted
        pharmacy system can record a confirmation, and it expires after a short time.
      </p>
    </Modal>
  );
}

export function AlternativesDialog({ medicine, onClose }) {
  const [state, setState] = useState({ loading: true, error: null, data: null });
  useEffect(() => {
    let live = true;
    api
      .alternatives(medicine.id)
      .then((r) => live && setState({ loading: false, error: null, data: r.data }))
      .catch((e) => live && setState({ loading: false, error: e.message, data: null }));
    return () => {
      live = false;
    };
  }, [medicine.id]);

  return (
    <Modal title={`Same composition as ${medicine.name}`} onClose={onClose}>
      {state.loading && <Loading label="Checking compositions…" />}
      {state.error && <ErrorState message={state.error} />}
      {state.data && (
        <>
          <p className="muted small">
            Matched on active ingredient, strength and dosage form — not on name.
          </p>
          {state.data.same_composition.length === 0 && state.data.needs_review.length === 0 && (
            <Empty title="No same-composition products in the database" />
          )}
          <ul className="alt-list">
            {state.data.same_composition.map((m) => (
              <li key={m.id}>
                <span className="badge badge-ok">Same composition</span> <strong>{m.name}</strong>
                <span className="muted small"> · {m.active_ingredient} {m.strength} {m.dosage_form}</span>
              </li>
            ))}
            {state.data.needs_review.map((m) => (
              <li key={m.id}>
                <span className="badge badge-warn">Needs review</span> <strong>{m.name}</strong>
                <span className="muted small"> · {m.reasons.join('; ')}</span>
              </li>
            ))}
          </ul>
          <p className="notice notice-info small">
            <Info size={16} aria-hidden="true" /> {state.data.note}
          </p>
        </>
      )}
    </Modal>
  );
}

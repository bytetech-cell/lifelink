import { ExternalLink, MapPin, PhoneCall, Pill, ShieldCheck } from 'lucide-react';
import { fullTime, hostOf, km, money, timeAgo } from '../services/format.js';
import { FreshnessTag, SourceTag, StockBadge } from './Status.jsx';

export function ListingCard({ item, onVerify, onAlternatives, highlight }) {
  const m = item.medicine;
  return (
    <article className={`card listing ${highlight ? 'listing-highlight' : ''}`}>
      <div className="listing-main">
        <div className="listing-head">
          <h3>{item.product_name}</h3>
          <SourceTag demo={item.is_demo} />
        </div>
        <p className="composition">
          <Pill size={14} aria-hidden="true" />
          {[m.active_ingredient || 'Ingredient not listed', m.strength || 'strength not listed', m.dosage_form || 'form not listed'].join(' · ')}
        </p>
        <p className="pharmacy-line">
          <MapPin size={14} aria-hidden="true" />
          <strong>{item.pharmacy.name}</strong>
          {item.distance_km !== null && <span className="muted"> · {km(item.distance_km)} away</span>}
        </p>
        <div className="listing-badges">
          <StockBadge stock={item.stock} />
          <FreshnessTag freshness={item.price_freshness} />
        </div>
        {item.stock?.evidence && (
          <p className="evidence">
            <ShieldCheck size={13} aria-hidden="true" /> {item.stock.evidence.confirmed_by} via{' '}
            {item.stock.evidence.source.replaceAll('_', ' ')}, {timeAgo(item.stock.evidence.confirmed_at)}
            {item.stock.code === 'confirmed' && <> · valid until {fullTime(item.stock.evidence.expires_at)}</>}
          </p>
        )}
      </div>

      <div className="listing-side">
        <div className="price-block">
          {item.price !== null ? (
            <>
              <span className="price">{money(item.price, item.currency)}</span>
              <span className="muted small">
                {item.pack_size ? `${item.pack_size} ${item.pack_unit || 'units'}` : 'pack size unknown'}
              </span>
              <span className="unit-price">
                {item.unit_price !== null ? `${money(item.unit_price, item.currency)} / unit` : 'Unit price unavailable'}
              </span>
            </>
          ) : (
            <span className="muted">Price not listed</span>
          )}
          <span className="muted tiny" title={fullTime(item.price_observed_at)}>
            Price seen {timeAgo(item.price_observed_at)} · {item.source?.name || 'unknown source'}
          </span>
        </div>
        <div className="listing-actions">
          <button className="btn btn-primary btn-sm" onClick={() => onVerify(item)}>
            <PhoneCall size={14} aria-hidden="true" /> Verify stock
          </button>
          {item.product_url ? (
            <a className="btn btn-ghost btn-sm" href={item.product_url} target="_blank" rel="noopener noreferrer">
              <ExternalLink size={14} aria-hidden="true" /> {hostOf(item.product_url)}
            </a>
          ) : (
            <span className="muted tiny">No source page (demo record)</span>
          )}
          {onAlternatives && (
            <button className="link-btn" onClick={() => onAlternatives(m)}>
              Same-composition options
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

export function LiveProductCard({ p }) {
  return (
    <article className="card listing">
      <div className="listing-main">
        <div className="listing-head">
          <h3>{p.product_name}</h3>
          <SourceTag live host={hostOf(p.source_website)} />
        </div>
        <p className="composition">
          <Pill size={14} aria-hidden="true" />
          {[p.active_ingredient || 'Ingredient not shown', p.strength || 'strength not shown', p.dosage_form || 'form not shown'].join(' · ')}
        </p>
        <div className="listing-badges">
          <StockBadge stock={{ code: 'unconfirmed' }} />
          {p.needs_review && <span className="tag tag-warn">Check details: {p.review_reasons.join(', ')}</span>}
        </div>
        <p className="evidence">
          {p.visible_stock_text ? (
            <>Website text: “{p.visible_stock_text}” — this is not a stock confirmation.</>
          ) : (
            <>The website showed no stock information.</>
          )}
        </p>
      </div>
      <div className="listing-side">
        <div className="price-block">
          {p.listed_price !== null ? (
            <>
              <span className="price">{money(p.listed_price, p.currency || 'INR')}</span>
              <span className="muted small">{p.pack_size_text || 'pack size not shown'}</span>
              <span className="unit-price">
                {p.unit_price !== null ? `${money(p.unit_price, p.currency || 'INR')} / unit` : 'Unit price unavailable'}
              </span>
            </>
          ) : (
            <span className="muted">Price not shown</span>
          )}
          <span className="muted tiny">Listed price · retrieved {timeAgo(p.retrieved_at)}</span>
        </div>
        <div className="listing-actions">
          {p.product_url ? (
            <a className="btn btn-ghost btn-sm" href={p.product_url} target="_blank" rel="noopener noreferrer">
              <ExternalLink size={14} aria-hidden="true" /> Open product page
            </a>
          ) : (
            <span className="muted tiny">{p.product_url_rejected ? 'Link removed (off-site or invalid)' : 'No product link found'}</span>
          )}
        </div>
      </div>
    </article>
  );
}

// Thin client for the VeriCare backend. All calls go to /api (same origin, proxied by Vite).
// The frontend never holds or sends any third-party API key.

export class ApiError extends Error {
  constructor(message, { status, code, demoFallback } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.demoFallback = Boolean(demoFallback);
  }
}

async function request(path, { method = 'GET', body, signal, headers } = {}) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      signal,
      headers: { 'Content-Type': 'application/json', ...(headers || {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    throw new ApiError('Cannot reach the VeriCare server. Is the backend running on port 8000?', { code: 'network' });
  }
  let json = null;
  try {
    json = await res.json();
  } catch {
    /* non-JSON */
  }
  if (!res.ok || !json || json.ok === false) {
    const e = json?.error || {};
    throw new ApiError(e.message || `Request failed (HTTP ${res.status})`, {
      status: res.status,
      code: e.code,
      demoFallback: e.demo_fallback_available,
    });
  }
  return json;
}

const qs = (params) =>
  new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')).toString();

export const api = {
  config: () => request('/config'),
  health: () => request('/health'),
  geocode: (q) => request(`/geocode?${qs({ q })}`),
  searchMedicines: ({ q, lat, lng, urgent }, signal) =>
    request(`/medicines/search?${qs({ q, lat, lng, urgent: urgent ? 'true' : undefined })}`, { signal }),
  alternatives: (id) => request(`/medicines/${id}/alternatives`),
  liveSearch: ({ medicine_name, site_url }, signal) =>
    request('/tinyfish/medicine-search', { method: 'POST', body: { medicine_name, site_url: site_url || undefined }, signal }),
  emergencyNearby: ({ lat, lng, area }, signal) => request(`/emergency/nearby?${qs({ lat, lng, area })}`, { signal }),
  pharmaciesNearby: ({ lat, lng }) => request(`/pharmacies/nearby?${qs({ lat, lng })}`),
};
